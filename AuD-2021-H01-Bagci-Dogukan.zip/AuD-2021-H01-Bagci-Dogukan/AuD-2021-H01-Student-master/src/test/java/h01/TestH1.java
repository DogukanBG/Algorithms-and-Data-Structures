package h01;

import org.junit.jupiter.api.Test;

import java.io.*;

import static org.junit.jupiter.api.Assertions.*;

public class TestH1 {

  @Test
  public void testMakeFlatListInPlace() {

    ListItem<ListItem<Character>> head = new ListItem<>(new ListItem<>('a'));
    head.key.next = new ListItem<Character>('1');
    head.key.next.next = new ListItem<>('g');

    head.next = new ListItem<ListItem<Character>>(new ListItem<Character>('b'));
    head.next.key.next = new ListItem<Character>('2');
    head.next.key.next.next = new ListItem<Character>('h');

    head.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('c'));
    head.next.next.key.next = new ListItem<Character>('3');
    head.next.next.key.next.next = new ListItem<Character>('i');

    head.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('d'));
    head.next.next.next.key.next = new ListItem<Character>('4');
    head.next.next.next.key.next.next = new ListItem<Character>('j');

    head.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('e'));
    head.next.next.next.next.key.next = new ListItem<Character>('5');
    head.next.next.next.next.key.next.next = new ListItem<Character>('k');

    head.next.next.next.next.next = new ListItem<ListItem<Character>>(null);

    head.next.next.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('f'));
    head.next.next.next.next.next.next.key.next = new ListItem<Character>('6');
    head.next.next.next.next.next.next.key.next.next = new ListItem<Character>('l');

    //******************************************************************************************//

    ListItem<Character> expected = new ListItem<>('a');
    expected.next = new ListItem<>('1');
    expected.next.next = new ListItem<>('g');

    expected.next.next.next = new ListItem<>('&');

    expected.next.next.next.next = new ListItem<>('b');
    expected.next.next.next.next.next = new ListItem<>('2');
    expected.next.next.next.next.next.next = new ListItem<>('h');

    expected.next.next.next.next.next.next.next = new ListItem<>('&');

    expected.next.next.next.next.next.next.next.next = new ListItem<>('c');
    expected.next.next.next.next.next.next.next.next.next = new ListItem<>('3');
    expected.next.next.next.next.next.next.next.next.next.next = new ListItem<>('i');

    expected.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    expected.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('d');
    expected.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('4');
    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('j');

    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('e');
    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('5');
    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('k');

    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('f');
    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('6');
    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('l');



    ListItem<Character> result = null;

    try {
      result = CharListProcessor.makeFlatListInPlace(head);
    } catch (ListOfListsException e) {
      System.out.println("Oh no it's a Exception!!!");
    }

    assertEquals(expected.key,result.key); //0
    assertEquals(expected.next.key,result.next.key); //1
    assertEquals(expected.next.next.key,result.next.next.key); //2
    assertEquals(expected.next.next.next.key,result.next.next.next.key); //3
    assertEquals(expected.next.next.next.next.key,result.next.next.next.next.key); //4
    assertEquals(expected.next.next.next.next.next.key,result.next.next.next.next.next.key); //5
    assertEquals(expected.next.next.next.next.next.next.key,result.next.next.next.next.next.next.key); //6
    assertEquals(expected.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.key); //7
    assertEquals(expected.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.key); //8
    assertEquals(expected.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.key); //9
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.key); //10.assertEquals(expected.next.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.next.key);
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.next.next.key);
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.next.next.next.key);
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key);
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key);
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key);
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key);
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key);



  }

  @Test //Test mit '&' in einer Einzelliste
  public void testMakeFlatListInPlaceExc(){
    ListItem<ListItem<Character>> head = new ListItem<>(new ListItem<>('a'));
    head.key.next = new ListItem<Character>('1');
    head.key.next.next = new ListItem<>('g');

    head.next = new ListItem<ListItem<Character>>(new ListItem<Character>('b'));
    head.next.key.next = new ListItem<Character>('2');
    head.next.key.next.next = new ListItem<Character>('h');

    head.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('c'));
    head.next.next.key.next = new ListItem<Character>('3');
    head.next.next.key.next.next = new ListItem<Character>('i');

    head.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('d'));
    head.next.next.next.key.next = new ListItem<Character>('4');
    head.next.next.next.key.next.next = new ListItem<Character>('j');

    head.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('e'));
    head.next.next.next.next.key.next = new ListItem<Character>('&');
    head.next.next.next.next.key.next.next = new ListItem<Character>('k');

    head.next.next.next.next.next = new ListItem<ListItem<Character>>(null);

    head.next.next.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('f'));
    head.next.next.next.next.next.next.key.next = new ListItem<Character>('6');
    head.next.next.next.next.next.next.key.next.next = new ListItem<Character>('l');

    ListOfListsException exc = assertThrows(ListOfListsException.class, ()->CharListProcessor.makeFlatListInPlace(head));
    assertEquals("sentinel character not allowed at position(4,1)",exc.getMessage());

  }

  @Test //Test mit 'null' in einer Einzelliste
  public void testMakeFlatListInPlaceExc2(){
    ListItem<ListItem<Character>> head = new ListItem<>(new ListItem<>('a'));
    head.key.next = new ListItem<Character>('1');
    head.key.next.next = new ListItem<>('g');

    head.next = new ListItem<ListItem<Character>>(new ListItem<Character>('b'));
    head.next.key.next = new ListItem<Character>('2');
    head.next.key.next.next = new ListItem<Character>('h');

    head.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('c'));
    head.next.next.key.next = new ListItem<Character>('3');
    head.next.next.key.next.next = new ListItem<Character>('i');

    head.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('d'));
    head.next.next.next.key.next = new ListItem<Character>('4');
    head.next.next.next.key.next.next = new ListItem<Character>('j');

    head.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('e'));
    head.next.next.next.next.key.next = new ListItem<Character>(null);
    head.next.next.next.next.key.next.next = new ListItem<Character>('k');

    head.next.next.next.next.next = new ListItem<ListItem<Character>>(null);

    head.next.next.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('f'));
    head.next.next.next.next.next.next.key.next = new ListItem<Character>('6');
    head.next.next.next.next.next.next.key.next.next = new ListItem<Character>('l');

    ListOfListsException exc = assertThrows(ListOfListsException.class, ()->CharListProcessor.makeFlatListInPlace(head));
    assertEquals("no object at position(4,1)",exc.getMessage());
  }

  @Test
  public void testMakeFlatListAsCopy(){
    ListItem<ListItem<Character>> head = new ListItem<>(new ListItem<>('a'));
    head.key.next = new ListItem<Character>('1');
    head.key.next.next = new ListItem<>('g');

    head.next = new ListItem<ListItem<Character>>(new ListItem<Character>('b'));
    head.next.key.next = new ListItem<Character>('2');
    head.next.key.next.next = new ListItem<Character>('h');

    head.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('c'));
    head.next.next.key.next = new ListItem<Character>('3');
    head.next.next.key.next.next = new ListItem<Character>('i');

    head.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('d'));
    head.next.next.next.key.next = new ListItem<Character>('4');
    head.next.next.next.key.next.next = new ListItem<Character>('j');

    head.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('e'));
    head.next.next.next.next.key.next = new ListItem<Character>('5');
    head.next.next.next.next.key.next.next = new ListItem<Character>('k');

    head.next.next.next.next.next = new ListItem<ListItem<Character>>(null);

    head.next.next.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('f'));
    head.next.next.next.next.next.next.key.next = new ListItem<Character>('6');
    head.next.next.next.next.next.next.key.next.next = new ListItem<Character>('l');

    //******************************************************************************************//

    ListItem<Character> expected = new ListItem<>('a');
    expected.next = new ListItem<>('1');
    expected.next.next = new ListItem<>('g');

    expected.next.next.next = new ListItem<>('&');

    expected.next.next.next.next = new ListItem<>('b');
    expected.next.next.next.next.next = new ListItem<>('2');
    expected.next.next.next.next.next.next = new ListItem<>('h');

    expected.next.next.next.next.next.next.next = new ListItem<>('&');

    expected.next.next.next.next.next.next.next.next = new ListItem<>('c');
    expected.next.next.next.next.next.next.next.next.next = new ListItem<>('3');
    expected.next.next.next.next.next.next.next.next.next.next = new ListItem<>('i');

    expected.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    expected.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('d');
    expected.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('4');
    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('j');

    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('e');
    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('5');
    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('k');

    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('f');
    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('6');
    expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('l');



    ListItem<Character> result = null;

    try {
      result = CharListProcessor.makeFlatListAsCopy(head);
    } catch (ListOfListsException e) {
      System.out.println("Oh no it's a Exception!!!");
    }
    assertEquals(expected.key,result.key); //0
    assertEquals(expected.next.key,result.next.key); //1
    assertEquals(expected.next.next.key,result.next.next.key); //2
    assertEquals(expected.next.next.next.key,result.next.next.next.key); //3
    assertEquals(expected.next.next.next.next.key,result.next.next.next.next.key); //4
    assertEquals(expected.next.next.next.next.next.key,result.next.next.next.next.next.key); //5
    assertEquals(expected.next.next.next.next.next.next.key,result.next.next.next.next.next.next.key); //6
    assertEquals(expected.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.key); //7
    assertEquals(expected.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.key); //8
    assertEquals(expected.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.key); //9
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.key); //10
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.next.key);
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.next.next.key);
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.next.next.next.key);
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key);
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key);
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key);
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key);
    assertEquals(expected.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key,result.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.key);

  }

  @Test //Test mit '&' in einer Einzelliste
  public void testMakeFlatListAsCopyExc(){
    ListItem<ListItem<Character>> head = new ListItem<>(new ListItem<>('a'));
    head.key.next = new ListItem<Character>('1');
    head.key.next.next = new ListItem<>('g');

    head.next = new ListItem<ListItem<Character>>(new ListItem<Character>('b'));
    head.next.key.next = new ListItem<Character>('2');
    head.next.key.next.next = new ListItem<Character>('h');

    head.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('c'));
    head.next.next.key.next = new ListItem<Character>('3');
    head.next.next.key.next.next = new ListItem<Character>('i');

    head.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('d'));
    head.next.next.next.key.next = new ListItem<Character>('4');
    head.next.next.next.key.next.next = new ListItem<Character>('j');

    head.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('e'));
    head.next.next.next.next.key.next = new ListItem<Character>('&');
    head.next.next.next.next.key.next.next = new ListItem<Character>('k');

    head.next.next.next.next.next = new ListItem<ListItem<Character>>(null);

    head.next.next.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('f'));
    head.next.next.next.next.next.next.key.next = new ListItem<Character>('6');
    head.next.next.next.next.next.next.key.next.next = new ListItem<Character>('l');

    ListOfListsException exc = assertThrows(ListOfListsException.class, ()->CharListProcessor.makeFlatListAsCopy(head));
    assertEquals("sentinel character not allowed at position(4,1)",exc.getMessage());

  }

  @Test //Test mit 'null' in einer Einzelliste
  public void testMakeFlatListAsCopyExc2(){
    ListItem<ListItem<Character>> head = new ListItem<>(new ListItem<>('a'));
    head.key.next = new ListItem<Character>('1');
    head.key.next.next = new ListItem<>('g');

    head.next = new ListItem<ListItem<Character>>(new ListItem<Character>('b'));
    head.next.key.next = new ListItem<Character>('2');
    head.next.key.next.next = new ListItem<Character>('h');

    head.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('c'));
    head.next.next.key.next = new ListItem<Character>('3');
    head.next.next.key.next.next = new ListItem<Character>('i');

    head.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('d'));
    head.next.next.next.key.next = new ListItem<Character>('4');
    head.next.next.next.key.next.next = new ListItem<Character>('j');

    head.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('e'));
    head.next.next.next.next.key.next = new ListItem<Character>(null);
    head.next.next.next.next.key.next.next = new ListItem<Character>('k');

    head.next.next.next.next.next = new ListItem<ListItem<Character>>(null);

    head.next.next.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('f'));
    head.next.next.next.next.next.next.key.next = new ListItem<Character>('6');
    head.next.next.next.next.next.next.key.next.next = new ListItem<Character>('l');

    ListOfListsException exc = assertThrows(ListOfListsException.class, ()->CharListProcessor.makeFlatListAsCopy(head));
    assertEquals("no object at position(4,1)",exc.getMessage());
  }

  @Test
  public void testMakeListOfListsInPlace(){

    ListItem<Character> head = new ListItem<>('a');
    head.next = new ListItem<>('1');
    head.next.next = new ListItem<>('g');

    head.next.next.next = new ListItem<>('&');

    head.next.next.next.next = new ListItem<>('b');
    head.next.next.next.next.next = new ListItem<>('2');
    head.next.next.next.next.next.next = new ListItem<>('h');

    head.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next = new ListItem<>('c');
    head.next.next.next.next.next.next.next.next.next = new ListItem<>('3');
    head.next.next.next.next.next.next.next.next.next.next = new ListItem<>('i');

    head.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('d');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('4');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('j');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('e');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('5');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('k');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('f');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('6');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('l');


    //******************************************************************************************//

    ListItem<ListItem<Character>> expected = new ListItem<>(new ListItem<>('a'));
    expected.key.next = new ListItem<Character>('1');
    expected.key.next.next = new ListItem<>('g');

    expected.next = new ListItem<ListItem<Character>>(new ListItem<Character>('b'));
    expected.next.key.next = new ListItem<Character>('2');
    expected.next.key.next.next = new ListItem<Character>('h');

    expected.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('c'));
    expected.next.next.key.next = new ListItem<Character>('3');
    expected.next.next.key.next.next = new ListItem<Character>('i');

    expected.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('d'));
    expected.next.next.next.key.next = new ListItem<Character>('4');
    expected.next.next.next.key.next.next = new ListItem<Character>('j');

    expected.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('e'));
    expected.next.next.next.next.key.next = new ListItem<Character>('5');
    expected.next.next.next.next.key.next.next = new ListItem<Character>('k');

    expected.next.next.next.next.next = new ListItem<ListItem<Character>>(null);

    expected.next.next.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('f'));
    expected.next.next.next.next.next.next.key.next = new ListItem<Character>('6');
    expected.next.next.next.next.next.next.key.next.next = new ListItem<Character>('l');

    //*************************************************************************************************************//

    ListItem<ListItem<Character>> result = null;
    ValidCharacterTest vctPred = new ValidCharacterTest();

    try {
      result = CharListProcessor.makeListOfListsInPlace(head,vctPred);
    } catch (Exception exc) {
      System.out.println("Oh no it's a Exception!!!");
    }

    assertEquals(expected.key.key,result.key.key); //0
    assertEquals(expected.key.next.key,result.key.next.key); //1
    assertEquals(expected.key.next.next.key,result.key.next.next.key); //2

    assertEquals(expected.next.key.key,result.next.key.key); //3
    assertEquals(expected.next.key.next.key,result.next.key.next.key); //4
    assertEquals(expected.next.key.next.next.key,result.next.key.next.next.key); //5

    assertEquals(expected.next.next.key.key,result.next.next.key.key); //6
    assertEquals(expected.next.next.key.next.key,result.next.next.key.next.key); //7
    assertEquals(expected.next.next.key.next.next.key,result.next.next.key.next.next.key); //8

    assertEquals(expected.next.next.next.key.key,result.next.next.next.key.key); //9
    assertEquals(expected.next.next.next.key.next.key,result.next.next.next.key.next.key); //10
    assertEquals(expected.next.next.next.key.next.next.key,result.next.next.next.key.next.next.key); //11

    assertEquals(expected.next.next.next.next.key.key,result.next.next.next.next.key.key);
    assertEquals(expected.next.next.next.next.key.next.key,result.next.next.next.next.key.next.key);
    assertEquals(expected.next.next.next.next.key.next.next.key,result.next.next.next.next.key.next.next.key);

    assertEquals(expected.next.next.next.next.next.key,result.next.next.next.next.next.key);

    assertEquals(expected.next.next.next.next.next.next.key.key,result.next.next.next.next.next.next.key.key);
    assertEquals(expected.next.next.next.next.next.next.key.next.key,result.next.next.next.next.next.next.key.next.key);
    assertEquals(expected.next.next.next.next.next.next.key.next.next.key,result.next.next.next.next.next.next.key.next.next.key);

  }

  @Test //Test mit 'null' in einer Einzelliste
  public void testMakeListOfListsInPlaceExc(){
    ListItem<Character> head = new ListItem<>('a');
    head.next = new ListItem<>('1');
    head.next.next = new ListItem<>('g');

    head.next.next.next = new ListItem<>('&');

    head.next.next.next.next = new ListItem<>('b');
    head.next.next.next.next.next = new ListItem<>('2');
    head.next.next.next.next.next.next = new ListItem<>('h');

    head.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next = new ListItem<>('c');
    head.next.next.next.next.next.next.next.next.next = new ListItem<>('3');
    head.next.next.next.next.next.next.next.next.next.next = new ListItem<>('i');

    head.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('d');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('4');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('j');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('e');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('5');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('k');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('f');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>(null);
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('l');

    //*************************************************************************************************************//

    ValidCharacterTest vctPred = new ValidCharacterTest();

    Exception result = assertThrows(Exception.class,()->CharListProcessor.makeListOfListsInPlace(head,vctPred));
    assertEquals("no object at position(6,1)",result.getMessage());

  }

  @Test
  public void testMakeListOfListAsCopy(){

    ListItem<Character> head = new ListItem<>('a');
    head.next = new ListItem<>('1');
    head.next.next = new ListItem<>('g');

    head.next.next.next = new ListItem<>('&');

    head.next.next.next.next = new ListItem<>('b');
    head.next.next.next.next.next = new ListItem<>('2');
    head.next.next.next.next.next.next = new ListItem<>('h');

    head.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next = new ListItem<>('c');
    head.next.next.next.next.next.next.next.next.next = new ListItem<>('3');
    head.next.next.next.next.next.next.next.next.next.next = new ListItem<>('i');

    head.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('d');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('4');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('j');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('e');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('5');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('k');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('f');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('6');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('l');


    //******************************************************************************************//

    ListItem<ListItem<Character>> expected = new ListItem<>(new ListItem<>('a'));
    expected.key.next = new ListItem<Character>('1');
    expected.key.next.next = new ListItem<>('g');

    expected.next = new ListItem<ListItem<Character>>(new ListItem<Character>('b'));
    expected.next.key.next = new ListItem<Character>('2');
    expected.next.key.next.next = new ListItem<Character>('h');

    expected.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('c'));
    expected.next.next.key.next = new ListItem<Character>('3');
    expected.next.next.key.next.next = new ListItem<Character>('i');

    expected.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('d'));
    expected.next.next.next.key.next = new ListItem<Character>('4');
    expected.next.next.next.key.next.next = new ListItem<Character>('j');

    expected.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('e'));
    expected.next.next.next.next.key.next = new ListItem<Character>('5');
    expected.next.next.next.next.key.next.next = new ListItem<Character>('k');

    expected.next.next.next.next.next = new ListItem<ListItem<Character>>(null);

    expected.next.next.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('f'));
    expected.next.next.next.next.next.next.key.next = new ListItem<Character>('6');
    expected.next.next.next.next.next.next.key.next.next = new ListItem<Character>('l');

    //*************************************************************************************************************//

    ListItem<ListItem<Character>> result = null;
    ValidCharacterTest vctPred = new ValidCharacterTest();

    try {
      result = CharListProcessor.makeListOfListsAsCopy(head,vctPred);
    } catch (Exception exc) {
      System.out.println("Oh no it's a Exception!!!");
    }

    assertEquals(expected.key.key,result.key.key); //0
    assertEquals(expected.key.next.key,result.key.next.key); //1
    assertEquals(expected.key.next.next.key,result.key.next.next.key); //2

    assertEquals(expected.next.key.key,result.next.key.key); //3
    assertEquals(expected.next.key.next.key,result.next.key.next.key); //4
    assertEquals(expected.next.key.next.next.key,result.next.key.next.next.key); //5

    assertEquals(expected.next.next.key.key,result.next.next.key.key); //6
    assertEquals(expected.next.next.key.next.key,result.next.next.key.next.key); //7
    assertEquals(expected.next.next.key.next.next.key,result.next.next.key.next.next.key); //8

    assertEquals(expected.next.next.next.key.key,result.next.next.next.key.key); //9
    assertEquals(expected.next.next.next.key.next.key,result.next.next.next.key.next.key); //10
    assertEquals(expected.next.next.next.key.next.next.key,result.next.next.next.key.next.next.key); //11

    assertEquals(expected.next.next.next.next.key.key,result.next.next.next.next.key.key);
    assertEquals(expected.next.next.next.next.key.next.key,result.next.next.next.next.key.next.key);
    assertEquals(expected.next.next.next.next.key.next.next.key,result.next.next.next.next.key.next.next.key);

    assertEquals(expected.next.next.next.next.next.key,result.next.next.next.next.next.key);

    assertEquals(expected.next.next.next.next.next.next.key.key,result.next.next.next.next.next.next.key.key);
    assertEquals(expected.next.next.next.next.next.next.key.next.key,result.next.next.next.next.next.next.key.next.key);
    assertEquals(expected.next.next.next.next.next.next.key.next.next.key,result.next.next.next.next.next.next.key.next.next.key);
  }

  @Test //Test mit 'null' in einer Einzelliste
  public void testMakeListOfListsAsCopyExc(){
    ListItem<Character> head = new ListItem<>('a');
    head.next = new ListItem<>('1');
    head.next.next = new ListItem<>('g');

    head.next.next.next = new ListItem<>('&');

    head.next.next.next.next = new ListItem<>('b');
    head.next.next.next.next.next = new ListItem<>('2');
    head.next.next.next.next.next.next = new ListItem<>('h');

    head.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next = new ListItem<>('c');
    head.next.next.next.next.next.next.next.next.next = new ListItem<>('3');
    head.next.next.next.next.next.next.next.next.next.next = new ListItem<>('i');

    head.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('d');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('4');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('j');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('e');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('5');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('k');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('&');

    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('f');
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>(null);
    head.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next.next = new ListItem<>('l');

    //*************************************************************************************************************//

    ValidCharacterTest vctPred = new ValidCharacterTest();

    Exception result = assertThrows(Exception.class,()->CharListProcessor.makeListOfListsAsCopy(head,vctPred));
    assertEquals("no object at position(6,1)",result.getMessage());

  }

  @Test
  public void testReverseListOfListsInPlaceIteratively(){

    ListItem<ListItem<Character>> head = new ListItem<>(new ListItem<>('a'));
    head.key.next = new ListItem<Character>('1');
    head.key.next.next = new ListItem<>('g');

    head.next = new ListItem<ListItem<Character>>(new ListItem<Character>('b'));
    head.next.key.next = new ListItem<Character>('2');
    head.next.key.next.next = new ListItem<Character>('h');

    head.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('c'));
    head.next.next.key.next = new ListItem<Character>('3');
    head.next.next.key.next.next = new ListItem<Character>('i');

    head.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('d'));
    head.next.next.next.key.next = new ListItem<Character>('4');
    head.next.next.next.key.next.next = new ListItem<Character>('j');

    head.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('e'));
    head.next.next.next.next.key.next = new ListItem<Character>('5');
    head.next.next.next.next.key.next.next = new ListItem<Character>('k');

    head.next.next.next.next.next = new ListItem<ListItem<Character>>(null);

    head.next.next.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('f'));
    head.next.next.next.next.next.next.key.next = new ListItem<Character>('6');
    head.next.next.next.next.next.next.key.next.next = new ListItem<Character>('l');

    //**********************************************************************************************************//

    ListItem<ListItem<Character>> expected = new ListItem<>(new ListItem<>('l'));
    expected.key.next = new ListItem<Character>('6');
    expected.key.next.next = new ListItem<>('f');

    expected.next = new ListItem<ListItem<Character>>(null);

    expected.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('k'));
    expected.next.next.key.next = new ListItem<Character>('5');
    expected.next.next.key.next.next = new ListItem<Character>('e');

    expected.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('j'));
    expected.next.next.next.key.next = new ListItem<Character>('4');
    expected.next.next.next.key.next.next = new ListItem<Character>('d');

    expected.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('i'));
    expected.next.next.next.next.key.next = new ListItem<Character>('3');
    expected.next.next.next.next.key.next.next = new ListItem<Character>('c');

    expected.next.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('h'));
    expected.next.next.next.next.next.key.next = new ListItem<Character>('2');
    expected.next.next.next.next.next.key.next.next = new ListItem<Character>('b');

    expected.next.next.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('g'));
    expected.next.next.next.next.next.next.key.next = new ListItem<Character>('1');
    expected.next.next.next.next.next.next.key.next.next = new ListItem<Character>('a');

    //***************************************************************************************************************//

    ListItem<ListItem<Character>> result = CharListProcessor.reverseListOfListsInPlaceIteratively(head);

    assertEquals(expected.key.key,result.key.key); //0
    assertEquals(expected.key.next.key,result.key.next.key); //1
    assertEquals(expected.key.next.next.key,result.key.next.next.key); //2

    assertEquals(expected.next.key,result.next.key); //3

    assertEquals(expected.next.next.key.key,result.next.next.key.key); //4
    assertEquals(expected.next.next.key.next.key,result.next.next.key.next.key); //5
    assertEquals(expected.next.next.key.next.next.key,result.next.next.key.next.next.key); //6

    assertEquals(expected.next.next.next.key.key,result.next.next.next.key.key); //7
    assertEquals(expected.next.next.next.key.next.key,result.next.next.next.key.next.key); //8
    assertEquals(expected.next.next.next.key.next.next.key,result.next.next.next.key.next.next.key); //9

    assertEquals(expected.next.next.next.next.key.key,result.next.next.next.next.key.key); //10
    assertEquals(expected.next.next.next.next.key.next.key,result.next.next.next.next.key.next.key); //11
    assertEquals(expected.next.next.next.next.key.next.next.key,result.next.next.next.next.key.next.next.key);

    assertEquals(expected.next.next.next.next.next.key.key,result.next.next.next.next.next.key.key);
    assertEquals(expected.next.next.next.next.next.key.next.key,result.next.next.next.next.next.key.next.key);
    assertEquals(expected.next.next.next.next.next.key.next.next.key,result.next.next.next.next.next.key.next.next.key);

    assertEquals(expected.next.next.next.next.next.next.key.key,result.next.next.next.next.next.next.key.key);
    assertEquals(expected.next.next.next.next.next.next.key.next.key,result.next.next.next.next.next.next.key.next.key);
    assertEquals(expected.next.next.next.next.next.next.key.next.next.key,result.next.next.next.next.next.next.key.next.next.key);

  }

  @Test
  public void testReverseListOfListsInPlaceRecursively(){
    ListItem<ListItem<Character>> head = new ListItem<>(new ListItem<>('a'));
    head.key.next = new ListItem<Character>('1');
    head.key.next.next = new ListItem<>('g');

    head.next = new ListItem<ListItem<Character>>(new ListItem<Character>('b'));
    head.next.key.next = new ListItem<Character>('2');
    head.next.key.next.next = new ListItem<Character>('h');

    head.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('c'));
    head.next.next.key.next = new ListItem<Character>('3');
    head.next.next.key.next.next = new ListItem<Character>('i');

    head.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('d'));
    head.next.next.next.key.next = new ListItem<Character>('4');
    head.next.next.next.key.next.next = new ListItem<Character>('j');

    head.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('e'));
    head.next.next.next.next.key.next = new ListItem<Character>('5');
    head.next.next.next.next.key.next.next = new ListItem<Character>('k');

    head.next.next.next.next.next = new ListItem<ListItem<Character>>(null);

    head.next.next.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('f'));
    head.next.next.next.next.next.next.key.next = new ListItem<Character>('6');
    head.next.next.next.next.next.next.key.next.next = new ListItem<Character>('l');

    //**********************************************************************************************************//

    ListItem<ListItem<Character>> expected = new ListItem<>(new ListItem<>('l'));
    expected.key.next = new ListItem<Character>('6');
    expected.key.next.next = new ListItem<>('f');

    expected.next = new ListItem<ListItem<Character>>(null);

    expected.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('k'));
    expected.next.next.key.next = new ListItem<Character>('5');
    expected.next.next.key.next.next = new ListItem<Character>('e');

    expected.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('j'));
    expected.next.next.next.key.next = new ListItem<Character>('4');
    expected.next.next.next.key.next.next = new ListItem<Character>('d');

    expected.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('i'));
    expected.next.next.next.next.key.next = new ListItem<Character>('3');
    expected.next.next.next.next.key.next.next = new ListItem<Character>('c');

    expected.next.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('h'));
    expected.next.next.next.next.next.key.next = new ListItem<Character>('2');
    expected.next.next.next.next.next.key.next.next = new ListItem<Character>('b');

    expected.next.next.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('g'));
    expected.next.next.next.next.next.next.key.next = new ListItem<Character>('1');
    expected.next.next.next.next.next.next.key.next.next = new ListItem<Character>('a');

    //***************************************************************************************************************//

    ListItem<ListItem<Character>> result = CharListProcessor.reverseListOfListsInPlaceRecursively(head);

    assertEquals(expected.key.key,result.key.key); //0
    assertEquals(expected.key.next.key,result.key.next.key); //1
    assertEquals(expected.key.next.next.key,result.key.next.next.key); //2

    assertEquals(expected.next.key,result.next.key); //3

    assertEquals(expected.next.next.key.key,result.next.next.key.key); //4
    assertEquals(expected.next.next.key.next.key,result.next.next.key.next.key); //5
    assertEquals(expected.next.next.key.next.next.key,result.next.next.key.next.next.key); //6

    assertEquals(expected.next.next.next.key.key,result.next.next.next.key.key); //7
    assertEquals(expected.next.next.next.key.next.key,result.next.next.next.key.next.key); //8
    assertEquals(expected.next.next.next.key.next.next.key,result.next.next.next.key.next.next.key); //9

    assertEquals(expected.next.next.next.next.key.key,result.next.next.next.next.key.key); //10
    assertEquals(expected.next.next.next.next.key.next.key,result.next.next.next.next.key.next.key); //11
    assertEquals(expected.next.next.next.next.key.next.next.key,result.next.next.next.next.key.next.next.key);

    assertEquals(expected.next.next.next.next.next.key.key,result.next.next.next.next.next.key.key);
    assertEquals(expected.next.next.next.next.next.key.next.key,result.next.next.next.next.next.key.next.key);
    assertEquals(expected.next.next.next.next.next.key.next.next.key,result.next.next.next.next.next.key.next.next.key);

    assertEquals(expected.next.next.next.next.next.next.key.key,result.next.next.next.next.next.next.key.key);
    assertEquals(expected.next.next.next.next.next.next.key.next.key,result.next.next.next.next.next.next.key.next.key);
    assertEquals(expected.next.next.next.next.next.next.key.next.next.key,result.next.next.next.next.next.next.key.next.next.key);

  }

  @Test
  public void testReadListOfListsOfChars(){

    try(BufferedReader reader = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("listOfLists.txt")))) {
      ListItem<ListItem<Character>> result = CharListProcessor.readListOfListsOfChars(reader);

      ListItem<ListItem<Character>> head = new ListItem<>(new ListItem<>('a'));
      head.key.next = new ListItem<Character>('1');
      head.key.next.next = new ListItem<>('g');

      head.next = new ListItem<ListItem<Character>>(new ListItem<Character>('b'));
      head.next.key.next = new ListItem<Character>('2');
      head.next.key.next.next = new ListItem<Character>('h');

      head.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('c'));
      head.next.next.key.next = new ListItem<Character>('3');
      head.next.next.key.next.next = new ListItem<Character>('i');

      head.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('d'));
      head.next.next.next.key.next = new ListItem<Character>('4');
      head.next.next.next.key.next.next = new ListItem<Character>('j');

      head.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('e'));
      head.next.next.next.next.key.next = new ListItem<Character>('5');
      head.next.next.next.next.key.next.next = new ListItem<Character>('k');

      head.next.next.next.next.next = new ListItem<ListItem<Character>>(null);

      head.next.next.next.next.next.next = new ListItem<ListItem<Character>>(new ListItem<Character>('f'));
      head.next.next.next.next.next.next.key.next = new ListItem<Character>('6');
      head.next.next.next.next.next.next.key.next.next = new ListItem<Character>('l');

      assertEquals(head.key.key,result.key.key); //0
      assertEquals(head.key.next.key,result.key.next.key); //1
      assertEquals(head.key.next.next.key,result.key.next.next.key); //2

      assertEquals(head.next.key.key,result.next.key.key); //3
      assertEquals(head.next.key.next.key,result.next.key.next.key); //4
      assertEquals(head.next.key.next.next.key,result.next.key.next.next.key); //5

      assertEquals(head.next.next.key.key,result.next.next.key.key); //6
      assertEquals(head.next.next.key.next.key,result.next.next.key.next.key); //7
      assertEquals(head.next.next.key.next.next.key,result.next.next.key.next.next.key); //8

      assertEquals(head.next.next.next.key.key,result.next.next.next.key.key); //9
      assertEquals(head.next.next.next.key.next.key,result.next.next.next.key.next.key); //10
      assertEquals(head.next.next.next.key.next.next.key,result.next.next.next.key.next.next.key); //11

      assertEquals(head.next.next.next.next.key.key,result.next.next.next.next.key.key);
      assertEquals(head.next.next.next.next.key.next.key,result.next.next.next.next.key.next.key);
      assertEquals(head.next.next.next.next.key.next.next.key,result.next.next.next.next.key.next.next.key);

      assertEquals(head.next.next.next.next.next.key,result.next.next.next.next.next.key);

      assertEquals(head.next.next.next.next.next.next.key.key,result.next.next.next.next.next.next.key.key);
      assertEquals(head.next.next.next.next.next.next.key.next.key,result.next.next.next.next.next.next.key.next.key);
      assertEquals(head.next.next.next.next.next.next.key.next.next.key,result.next.next.next.next.next.next.key.next.next.key);


    } catch (IOException exc) { System.err.println(exc.getMessage());}
  }

}
