package h01;

public class ValidCharacterTest implements PredicateWithException<Character>{


  @Override
  public boolean test(Character character, int i, int j) throws Exception {
    if (character==null)
      throw new ListOfListsException(i, j, true);
    if(character.charValue() == '&')
      return true;
    return false;
  }
}
