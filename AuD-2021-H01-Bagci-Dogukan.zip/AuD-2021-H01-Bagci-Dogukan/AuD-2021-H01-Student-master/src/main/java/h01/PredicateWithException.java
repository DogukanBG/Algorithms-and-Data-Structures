package h01;

public interface PredicateWithException <T>{

  public boolean test(T t, int i, int j) throws Exception;
}
