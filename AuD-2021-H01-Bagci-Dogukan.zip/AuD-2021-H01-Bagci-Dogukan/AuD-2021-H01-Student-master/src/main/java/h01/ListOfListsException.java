package h01;

public class ListOfListsException extends Exception{

  public ListOfListsException(int i, int j, boolean bool){
    super((bool?
      "no object" :
      "sentinel character not allowed")
      + " at position(" +i+","+j+")");

  }
}
