package h01;

public class ListItem <T>{

  public T key;
  public ListItem<T> next;

  public ListItem(){}
  public ListItem(T key){this.key = key;}

  @Override
  public String toString(){
    return "ListItem " + key;
  }

}
