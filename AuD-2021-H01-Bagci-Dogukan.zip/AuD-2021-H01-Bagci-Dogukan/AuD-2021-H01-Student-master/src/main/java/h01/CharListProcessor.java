package h01;

import java.io.BufferedReader;
import java.io.IOException;

public class CharListProcessor {

  public static ListItem<Character> makeFlatListInPlace(ListItem<ListItem<Character>> listOfLists) throws ListOfListsException {
    int innerPos = 0;
    int outerPos = 0;

    ListItem<Character> head = null;
    ListItem<Character> tail = null;
    ListItem<ListItem<Character>> pOuterList = listOfLists;
    ListItem<Character> pInnerList;
    ListItem<Character> tmp;


    while(pOuterList!=null){
      pInnerList = pOuterList.key;
      tmp = pOuterList.key;
      innerPos = 0;
      //prüfen, ob ein element in der einzelliste ist, das nicht drinnen sein sollte
      while(pInnerList!=null){

        if (pInnerList.key == null) throw new ListOfListsException(outerPos, innerPos, true);
        if (pInnerList.key == '&') throw new ListOfListsException(outerPos, innerPos, false);
        if(head == null) {
          head = tail = pInnerList;
        }
        else {
          tail.next = pInnerList;
          tail = tail.next;
        }
        pInnerList = pInnerList.next;
        innerPos++;
      }
      if (pOuterList.next!=null) {
        //tmp.next = new ListItem<>('&');
        tail.next = new ListItem<>('&');
        tail = tail.next;

      }else {
        break;
      }
      pOuterList = pOuterList.next;
      outerPos++;
    }

    return head;
  }

  public static ListItem<Character> makeFlatListAsCopy(ListItem<ListItem<Character>> listOfLists) throws ListOfListsException {
    int innerPos = 0;
    int outerPos = 0;

    ListItem<Character> head = null;
    ListItem<Character> tail = null;
    ListItem<ListItem<Character>> pOuterList = listOfLists;
    ListItem<Character> pInnerList;


    while (pOuterList != null) {
      pInnerList = pOuterList.key;
      innerPos = 0;
      while (pInnerList != null) {
        ListItem<Character> tmp = new ListItem<>(pInnerList.key);
        if (pInnerList.key == null) throw new ListOfListsException(outerPos, innerPos, true);
        if (pInnerList.key == '&') throw new ListOfListsException(outerPos, innerPos, false);

        if (head == null)
          head = tail = tmp;

        else {
          tail.next = tmp;
          tail = tail.next;
        }
        innerPos++;
        pInnerList = pInnerList.next;
      }
      ListItem<Character> tmp = new ListItem<>('&');

      if (pOuterList.next == null) {
        break;
      }

      if (head == null)
        head = tail = tmp;

      else {
        tail.next = tmp;
        tail = tail.next;
      }
      pOuterList = pOuterList.next;
      outerPos++;

    }
    return head;
  }


  public static ListItem<ListItem<Character>> makeListOfListsInPlace(ListItem<Character> list, PredicateWithException<Character> pred) throws Exception {
    int innerPos = 0;
    int outerPos = 0;

    ListItem<ListItem<Character>> head = null;
    ListItem<ListItem<Character>> tail = null;
    ListItem<Character> p = list, p2 = list;
    ListItem<Character> innerHead = null;
    ListItem<Character> innerTail = null;

    while (p != null) {

      if (!pred.test(p.key,outerPos,innerPos)){
        if (innerHead==null){
          innerHead = innerTail = p2;
        }
        else {
          innerTail.next = p2;
          innerTail = innerTail.next;
        }
        innerPos++;
      }
      else{

        if (head == null) {
          head = tail = new ListItem<ListItem<Character>>(innerHead);
        }
        else {
          tail.next = new ListItem<ListItem<Character>>(innerHead);
          tail = tail.next;
        }
        innerHead = null;
        innerTail = null;

        outerPos++;
        innerPos=0;
      }

      if (p.next == null) {
        if (head == null) {
          head = tail = new ListItem<ListItem<Character>>(innerHead);
        }
        else {
          tail.next = new ListItem<ListItem<Character>>(innerHead);
          tail = tail.next;
        }
        innerHead = null;
        innerTail = null;
      }

      p = p.next;
      p2.next = null;
      p2 = p;
    }
    return head;
  }

  public static ListItem<ListItem<Character>> makeListOfListsAsCopy(ListItem<Character> list, PredicateWithException<Character> pred) throws Exception {
    int innerPos = 0;
    int outerPos = 0;

    ListItem<ListItem<Character>> head = null;
    ListItem<ListItem<Character>> tail = null;
    ListItem<Character> p = list;
    ListItem<Character> innerHead = null;
    ListItem<Character> innerTail = null;

    while (p != null) {

      if (!pred.test(p.key,outerPos,innerPos)){
        if (innerHead==null){
          innerHead = innerTail = new ListItem<>(p.key);
        }
        else{
          innerTail.next = new ListItem<>(p.key);
          innerTail = innerTail.next;
        }
        innerPos++;
      }
      else{

        if (head == null) {
          head = tail = new ListItem<ListItem<Character>>(innerHead);
        }
        else {
          tail.next = new ListItem<ListItem<Character>>(innerHead);
          tail = tail.next;
        }
        innerHead = null;
        innerTail = null;

        outerPos++;
        innerPos=0;
      }

      if (p.next == null) {
        if (head == null) {
          head = tail = new ListItem<ListItem<Character>>(innerHead);
        }
        else {
          tail.next = new ListItem<ListItem<Character>>(innerHead);
          tail = tail.next;
        }
        innerHead = null;
        innerTail = null;
      }

      p = p.next;
    }
    return head;

  }

  public static ListItem<ListItem<Character>> reverseListOfListsInPlaceIteratively(ListItem<ListItem<Character>> listOfLists) {

    ListItem<ListItem<Character>> head = null, p = listOfLists, rest = listOfLists;

    while (rest != null) {
      rest = rest.next;
      p.next = null;

      if (head == null)
        head = p;
      else {
        p.next = head;
        head = p;
      }

      p = rest;
    }

    p = rest = head;
    ListItem<Character> innerHead = null, innerP, innerRest;

    while (p != null) {

      innerP = innerRest = p.key;
      innerHead = null;

      while (innerRest != null) {
        innerRest = innerRest.next;
        innerP.next = null;

        if (innerHead == null)
          innerHead = innerP;
        else {
          innerP.next = innerHead;
          innerHead = innerP;
        }
        innerP = innerRest;
      }

      p.key = innerHead;
      p = p.next;
    }
    return head;
  }


  //for the outer lists
  public static ListItem<ListItem<Character>> reverseListOfListsInPlaceRecursively(ListItem<ListItem<Character>> listOfLists){
    if (listOfLists == null) {
      return listOfLists;
    }
    if (listOfLists.next==null) {
      listOfLists.key = reverseList(listOfLists.key);
      return listOfLists;
    }
    else{
      ListItem<ListItem<Character>> rest = listOfLists.next;
      listOfLists.next = null;
      ListItem<ListItem<Character>> reverse = reverseListOfListsInPlaceRecursively(rest);
      listOfLists.key = reverseList(listOfLists.key);
      rest.next = listOfLists;

      return reverse;
    }
  }

  //for the inner lists (also "in-place")
  private static ListItem<Character> reverseList(ListItem<Character> listOfLists){
    if (listOfLists == null || listOfLists.next==null)
      return listOfLists;
    else{
      ListItem<Character> rest = listOfLists.next;
      listOfLists.next = null;
      ListItem<Character> reverse = reverseList(rest);
      rest.next = listOfLists;
      return reverse;
    }
  }

  public static ListItem<ListItem<Character>> readListOfListsOfChars(BufferedReader reader){

    try{

      ListItem<ListItem<Character>> head = null;
      ListItem<ListItem<Character>> tail = null;
      ListItem<Character> innerHead = null;
      ListItem<Character> innerTail = null;


      String line;
      int n = Integer.parseInt(reader.readLine()), i = 0;

      while(i<n){
        i++;
        line = reader.readLine();

        if (line==null){
          ListItem<ListItem<Character>> tmp = new ListItem<>(new ListItem<>());
          if (head==null)
            head = tail = tmp;
          else{
            tail.next = tmp;
            tail = tail.next;
          }
          continue;
        }
        for (int j=0; j<line.length();j++){
          char ch  = line.charAt(j);
          if (Character.isUpperCase(ch)||Character.isWhitespace(ch)) continue;
          ListItem<Character> tmp = new ListItem<>(ch);
          if (innerHead==null)
            innerHead = innerTail = tmp;
          else{
            innerTail.next = tmp;
            innerTail = innerTail.next;
          }
        }
        if (head==null)
          head = tail = new ListItem<>(innerHead);
        else{
          tail.next = new ListItem<>(innerHead);
          tail = tail.next;
        }
        innerHead = null;
        innerTail = null;

      }
      return head;
    }
    catch(NumberFormatException | IOException exc){
      return null;
    }

  }
}

