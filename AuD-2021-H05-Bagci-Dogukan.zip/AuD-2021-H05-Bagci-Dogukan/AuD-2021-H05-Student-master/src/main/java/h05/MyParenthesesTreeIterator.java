package h05;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Stack;

public class MyParenthesesTreeIterator implements Iterator<Character> {

  private MyTreeNode root;
  private Stack<ListItem<MyTreeNode>> stack;
  private MyTreeNode p;

  public MyParenthesesTreeIterator(MyTreeNode root){
    this.root = p = root;
    stack = new Stack<>();
    stack.push(root.successors);
  }


  @Override
  public boolean hasNext() {
 /*   if (stack.peek().nodeID == root.nodeID && root.succe==null){
      root.succe = root.successors;
      return false;
    }
    else{
      if (!stack.empty()){
        return true;
      }
    }*/
 /*   if (stack.peek()==null || root == null || root.successors == null)
      return false;
    if (stack.peek().next == null)
      return false;
    else{
      if (!stack.empty())
        return true;
    }*/
    if (stack.peek()==null && stack.size()==1)
      return false;
    if(!stack.empty())
      return true;
    return false;
  }

  @Override
  public Character next() {
    if (!hasNext()) {
      throw new NoSuchElementException();
    }
   /* if (stack.peek().succe!=null){
      MyTreeNode node = stack.peek().succe.key;
      MyTreeNode peeked = stack.peek();
      peeked.succe = peeked.succe.next;
      stack.push(node);

      return '(';
    }
    else{
      MyTreeNode node = stack.pop();
      node.succe = node.successors;
      return ')';
    }*/
    if (stack.peek() != null){
      ListItem<MyTreeNode> item = stack.peek().key.successors;
      ListItem<MyTreeNode> popped = stack.pop();
      popped = popped.next;
      stack.push(popped);
      stack.push(item);
      return '(';
    }
    else{
      ListItem<MyTreeNode> item = stack.pop();
      return ')';
    }
  }


    @Override
    public void remove() { throw new UnsupportedOperationException();
    }

  }
