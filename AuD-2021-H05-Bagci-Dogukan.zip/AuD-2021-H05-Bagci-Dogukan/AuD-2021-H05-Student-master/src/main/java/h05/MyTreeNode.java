package h05;

public class MyTreeNode {

  public final long nodeID;
  public ListItem<MyTreeNode> successors;
  protected ListItem<MyTreeNode> succe;
  private ListItem<MyTreeNode> tail;

  public MyTreeNode(long nodeID){
    this.nodeID = nodeID;
    this.successors = null;
    this.succe = null;
    this.tail = null;
  }

  public void add(MyTreeNode node){
/*    ListItem<MyTreeNode> item = new ListItem<>();
    item.key = node;
    item.next = null;
    if (successors == null){
      this.successors = succe = item;
      return;
    }
    ListItem<MyTreeNode> p = successors;
    while(p.next!=null){
      p = p.next;
    }
    p.next = item;
    succe = successors;*/
    if (node==null)
      return;
    ListItem<MyTreeNode> item = new ListItem<>();
    item.key = node;
    item.next = null;
    if(successors==null){
      successors = succe = tail = item;
    }
    else{
      tail.next = item;
      tail = tail.next;
    }
  }

  public void addRec (ListItem<MyTreeNode> node, ListItem<MyTreeNode> p){
    if (p==null){
      p = node;
      return;
    }
    if (p.next==null){
      p.next = node;
      return;
    }
    addRec(node,p.next);
  }




}
