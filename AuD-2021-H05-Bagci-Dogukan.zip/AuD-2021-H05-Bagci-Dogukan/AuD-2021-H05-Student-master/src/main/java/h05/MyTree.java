package h05;

import javax.management.BadStringOperationException;
import java.io.IOException;
import java.io.Reader;
import java.util.Iterator;
import java.util.Stack;

public class MyTree implements Iterable<Character> {

  private MyTreeNode root;
  private static long nextNodeID;
  public Stack<MyTreeNode> prvStk;

  static {
    nextNodeID = 0;
  }

  public MyTree(Reader reader, boolean bool) throws BadStringOperationException, IOException {
    Stack<MyTreeNode> stack = new Stack<>();
    prvStk = new Stack<>();
    if (bool) {
      root = new MyTreeNode(nextNodeID);
      nextNodeID++;
      rootBuilder(reader);
    }
    else
      root = buildIteratively(reader, stack);
  }

  private void rootBuilder(Reader reader) throws IOException, BadStringOperationException {
    char c = (char) reader.read();
    //
    if(c == '\uFFFF' || c == -1 || (c!='\n' && c!='(' && c != ')')){
      throw new BadStringOperationException("Bad String: line 34");
    }
    if (c == '\n') {
      return;
    }
    if (c == '(') {
      MyTreeNode node = buildRecursively(reader);
      root.add(node);
      rootBuilder(reader);
      return;
    }
    if (c == ')') {
      if (prvStk.empty())
        throw new BadStringOperationException("Bad String: line 47");
      rootBuilder(reader);
    }

  }

  private MyTreeNode buildRecursively(Reader reader) throws BadStringOperationException, IOException {
    MyTreeNode node = new MyTreeNode(nextNodeID);
    nextNodeID++;
    prvStk.push(node);
    char c = (char) reader.read();
    if (c == '(') {
      MyTreeNode no = buildRecursively(reader);
      ListItem<MyTreeNode> item = new ListItem<>();
      item.key = no;
      if (!prvStk.empty()) {
        MyTreeNode peeked = prvStk.peek();
        peeked.add(no);
      }
      return node;
      // (() | ())
    }
    if (c == ')') {
      if (prvStk.empty())
        throw new BadStringOperationException("Bad String: line 70");
      MyTreeNode popped = prvStk.pop();
      if(prvStk.empty())
        return popped;
      else{
        MyTreeNode peeked = prvStk.peek();
        peeked.add(popped);
        return null;
      } //(()(
    }
   else
     throw new BadStringOperationException("Bad String: line 81");

  }


  public boolean isIsomorphic(MyTree tree){
    MyTreeNode root1 = root;
    MyTreeNode root2 = tree.root;

    if (root1 == null && root2 == null)
      return true;

    if(root1 != null && root2 == null)
      return false;

    if (root1 == null && root2 != null)
      return false;

    ListItem<MyTreeNode> p1 = root1.successors, p2 = root2.successors;
    Stack<MyTreeNode> stack1 = new Stack<>();
    Stack<MyTreeNode> stack2 = new Stack<>();

    return isSame(p1,p2);
  }

  private boolean isSame(ListItem<MyTreeNode> p1, ListItem<MyTreeNode> p2) {
    //successorors prüfen
    if (p1==null && p2==null)
      return true;
    if (p1!=null && p2 ==null)
      return false;
    if (p1==null && p2 !=null)
      return false;

   //keys prüfen
    if (p1.key == null && p2.key == null)
      return true;
    if (p1.key != null && p2.key == null)
      return false;
    if (p1.key == null && p2.key != null)
      return false;
    ListItem<MyTreeNode> p3 = p1.key.successors, p4 = p2.key.successors;
    boolean bool2 = isSame(p3,p4);

    //next prüfen
    if (p1.next != null && p2.next == null)
      return false;
    if (p1.next == null && p2.next != null)
      return false;

    p1 = p1.next; p2 = p2.next;
    boolean bool1 = isSame(p1,p2);

    return bool1 && bool2;
  }


  private MyTreeNode buildIteratively(Reader reader, Stack<MyTreeNode> stack) throws BadStringOperationException, IOException {
    MyTreeNode root = new MyTreeNode(nextNodeID);
    nextNodeID++;
    char c = (char) reader.read();

    if (c==-1||c=='\uFFFF')
      throw new BadStringOperationException("Bad String");

    while(c!='\n'){
      if (c=='\n')
        break;

      if (c=='(') {
        MyTreeNode node = new MyTreeNode(nextNodeID);
        nextNodeID++;
        stack.push(node);
        c = (char) reader.read();
        continue;
      }

      if (c==')'){
        if (stack.empty()){
          throw new BadStringOperationException("Bad String");
        }

        MyTreeNode popped = stack.pop();

        if (stack.empty()) {
          root.add(popped);
        }
        else{
          MyTreeNode rootOfPopped = stack.peek();
          rootOfPopped.add(popped);
        }
        c = (char) reader.read();
        continue;
      }
      else
        throw new BadStringOperationException("Bad String");
    }
    if (!stack.empty())
      throw new BadStringOperationException("Bad String");

    return root;
  }

  @Override
  public Iterator<Character> iterator() {
    return new MyParenthesesTreeIterator(root);
  }
}
