package h05;


import javax.management.BadStringOperationException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;


public class Main {
  public static void main(String[] args) throws IOException {
    MyTree tree = null, tree2 = null;
    Reader reader = new StringReader("()()“\n");
    try {
      tree = new MyTree(reader, true);
    } catch (BadStringOperationException e) {
      // TODO Auto-generated catch block
      System.out.println(e.getMessage());
    }

   MyParenthesesTreeIterator it = (MyParenthesesTreeIterator) tree.iterator();
    MyParenthesesTreeIterator it2 = (MyParenthesesTreeIterator) tree.iterator();
    while(it.hasNext()){
      char c = it.next();
      System.out.print(c);
    }
    System.out.println();
    while(it2.hasNext()){
      char c = it2.next();
      System.out.print(c);
    }

 /*   MyTreeNode Tss = rootList.key;
    ListItem<MyTreeNode> TssList = Tss.successors;

   while(TssList != null) {
      System.out.println("---------node ID: " + TssList.key.nodeID);
      System.out.println(TssList.key.successors != null);
      TssList  = TssList.next;
    }*/

  }
}
