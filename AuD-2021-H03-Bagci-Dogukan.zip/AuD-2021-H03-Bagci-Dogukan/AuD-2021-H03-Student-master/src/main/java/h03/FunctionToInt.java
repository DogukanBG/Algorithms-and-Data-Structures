package h03;

public interface FunctionToInt <T>{

  /**
   * Returns size of Alphabet
   *
   * @return size of Aplhabet
   */
  int sizeOfAlphabet();

  /**
   * Returns a non-negative number x with 0<=x< sizeOfAlphabet
   *
   * @param t
   * @return a non-negative number x with 0<=x< sizeOfAlphabet
   * @throws IllegalArgumentException
   */
  int apply(T t) throws IllegalArgumentException;

}
