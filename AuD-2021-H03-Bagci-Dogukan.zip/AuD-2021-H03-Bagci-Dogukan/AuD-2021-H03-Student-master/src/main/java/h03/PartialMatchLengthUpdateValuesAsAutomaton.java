package h03;

import java.util.*;

public class PartialMatchLengthUpdateValuesAsAutomaton <T> extends PartialMatchLengthUpdateValues<T> {

  private List<Transition<T>>[] theStates;
  private T[] realAlp;
  private int searchStringLength;

  public PartialMatchLengthUpdateValuesAsAutomaton(FunctionToInt func,T[] searchString){
    super(func);

    searchStringLength = searchString.length; //Nachtrag für H7

    if(searchString .length == 0) {
      theStates = (List<Transition<T>>[]) new LinkedList[1];
      return;
    }

    theStates =  new List[searchString.length+1];
    int sizeOfAlp = func.sizeOfAlphabet();
    realAlp = (T[]) new Object[sizeOfAlp];

    //Die Buchstaben, die in searchString enthalten sind, sind nicht 'null'
    for (int i = 0; i < searchString.length; i++)
      realAlp[func.apply(searchString[i])] = searchString[i];


    //Trivialer Fall Zustand 1
    theStates[0] = new LinkedList<>();
    LinkedList<T> list = new LinkedList<>();
    list.add(searchString[0]);
    Transition<T> tra = new Transition<T>(1,list);
    theStates[0].add(tra);

    for (int i = 1; i < theStates.length; i++) {
      theStates[i] = new LinkedList<>();

      for (int k = 0; k < realAlp.length; k++) {
        LinkedList<T> tranList = new LinkedList<>();

        if (realAlp[k]==null){ continue; }

        //der richtige Buchstabe
        if (i!=searchString.length) {
          if (realAlp[k] == searchString[i]) {
            tranList.add(realAlp[k]);
            Transition<T> tran = new Transition<>(i + 1, tranList);
            theStates[i].add(tran);
          }
          //der falsche Buchstabe
          else {
            T[] tmp = (T[]) new Object[i + 1];
            for (int l = 0; l < tmp.length - 1; l++) {
              tmp[l] = searchString[l];
            }
            tmp[tmp.length - 1] = realAlp[k];
            int comp = computePartialMatchLengthUpdateValues(tmp);
            if (comp > 0) {
              tranList.add(realAlp[k]);
              Transition<T> tran = new Transition<>(comp, tranList);
              theStates[i].add(tran);
            }
          }
        }else{
          T[] tmp = (T[]) new Object[i + 1];
          for (int l = 0; l < tmp.length - 1; l++) {
            tmp[l] = searchString[l];
          }
          tmp[tmp.length - 1] = realAlp[k];
          int comp = computePartialMatchLengthUpdateValues(tmp);
          if (comp > 0) {
            tranList.add(realAlp[k]);
            Transition<T> tran = new Transition<>(comp, tranList);
            theStates[i].add(tran);
          }
        }
      }
    }



    }

  @Override
  public int getPartialMatchLengthUpdate(int n, T t) {
    func.apply(t);

    if (searchStringLength==0)
      return 0;

    boolean contains = false;
    for (int i = 0; i < realAlp.length; i++) {
      if (t == realAlp[i])
        contains = true;
    }
    if (contains)
      return theStates[n].get(func.apply(t)).j;
    return 0;
  }

  @Override
  public int getSearchStringLength() {
    return searchStringLength;
  }

  public T[] getRealAlp() {
    return realAlp;
  }

  public List<Transition<T>>[] getTheStates() {
    return theStates;
  }
}
