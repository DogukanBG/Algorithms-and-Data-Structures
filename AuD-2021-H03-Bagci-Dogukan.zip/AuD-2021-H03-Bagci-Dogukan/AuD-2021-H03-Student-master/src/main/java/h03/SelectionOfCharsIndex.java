package h03;

import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class SelectionOfCharsIndex implements FunctionToInt<Character>{

  private char[] theChars;

  /**
   * @param theAlphabet has at least one element (especially not null)
   */
  public SelectionOfCharsIndex(List<Character> theAlphabet){
    theChars = new char[theAlphabet.size()];
    Iterator<Character> it = theAlphabet.iterator();

    for(int i=0; it.hasNext();i++){
      theChars[i] = it.next();
    }
  }

  /**
   * Returns the size of the Alphabet
   *
   * @return the size of the Alphabet
   */
  @Override
  public int sizeOfAlphabet() {
    return theChars.length;
  }

  /**
   * Returns the Index of cha in the Alphabet
   *
   * @param cha the given enum
   * @return the Index of cha in the Alphabet
   * @throws IllegalArgumentException the cha is not found
   */
  @Override
  public int apply(Character cha) throws IllegalArgumentException {
    for (int i = 0; i<theChars.length;i++){
      if (cha.equals(theChars[i]))
        return i;
    }
    throw new IllegalArgumentException();
  }
}
