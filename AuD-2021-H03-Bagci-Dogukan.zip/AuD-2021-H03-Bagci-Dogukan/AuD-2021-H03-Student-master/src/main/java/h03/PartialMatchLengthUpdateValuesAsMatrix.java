package h03;


public class PartialMatchLengthUpdateValuesAsMatrix<T> extends PartialMatchLengthUpdateValues<T> {

  private int searchStringLength;
  private int[][] lookupTable;

  private T[] realAlp;

  public PartialMatchLengthUpdateValuesAsMatrix(FunctionToInt func, T[] searchString) {
    super(func);

    searchStringLength = searchString.length; //Nachtrag für H7

    // Sonderfall: Suchstring leer
    if(searchString.length == 0) {
      lookupTable = new int[1][func.sizeOfAlphabet()];
      return;
    }

    int sizeOfAlp = func.sizeOfAlphabet();

    lookupTable = new int[sizeOfAlp][searchString.length + 1];
    realAlp = (T[]) new Object[sizeOfAlp];

    //Initialisierung der "trivialen" Zustände
    for (int j = 0; j < searchString.length; j++) {
      lookupTable[func.apply(searchString[j])][j] = j + 1;
    }

    //Die Buchstaben, die in searchString enthalten sind, sind nicht 'null'
    for (int i = 0; i < searchString.length; i++)
      realAlp[func.apply(searchString[i])] = searchString[i];


    //Die Restlichen Fälle
    for (int i = 0; i < sizeOfAlp; i++) {
      for (int j = 1; j <= searchString.length; j++) {
        if (lookupTable[i][j] == 0 && realAlp[i] != null) {
          T[] state = (T[]) new Object[j + 1];
          for (int k = 0; k < state.length-1;k++) {
            state[k] = searchString[k];
          }
          state[state.length - 1] = realAlp[i];
          int comp = computePartialMatchLengthUpdateValues(state);
          lookupTable[i][j] = comp;
        }
      }
    }
  }

  @Override
  public int getPartialMatchLengthUpdate(int n, T t) {
    return lookupTable[n][func.apply(t)];
  }

  @Override
  public int getSearchStringLength() {
    return searchStringLength;
  }

  public int[][] getLookupTable() {
    return lookupTable;
  }

  public T[] getRealAlp() {
    return realAlp;
  }
}
