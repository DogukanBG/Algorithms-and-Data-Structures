package h03;

import java.util.*;

public class StringMatcher <T>{

  private PartialMatchLengthUpdateValues<T> pmluv;

  public StringMatcher(PartialMatchLengthUpdateValues pmluv){
    this.pmluv = pmluv;
  }

  public List<Integer> findAllMatches(T[] source){

    List<Integer> matches = new LinkedList<>();

    int patLen = pmluv.getSearchStringLength();
    int txtLen = source.length;
    int state = 0;

    for (int i = 0; i < txtLen; i++) {

      state = pmluv.getPartialMatchLengthUpdate(state, source[i]);
      if (state == patLen)
        matches.add(i - patLen + 1);

    }
    if(pmluv.getSearchStringLength() == 0)
      return new LinkedList<Integer>();

    return matches;
  }

}
