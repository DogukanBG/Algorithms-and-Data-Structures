package h03;

import java.util.List;

public class Transition <T> {

  public int j;
  public List<T> listOfT;

  public Transition(int j,List<T> listOfT){
    this.j = j;
    this.listOfT = listOfT;
  }

}
