package h03;

public abstract class PartialMatchLengthUpdateValues <T>{

  protected FunctionToInt func;

  public PartialMatchLengthUpdateValues(FunctionToInt func){
    this.func = func;
  }

  public abstract int getPartialMatchLengthUpdate(int n, T t);

  public abstract int getSearchStringLength();

  /**
   * Returns the biggest number k (k<searchString.length), wh
   *
   * @param searchString
   * @return
   */
  protected int computePartialMatchLengthUpdateValues(T[] searchString){

    if(searchString == null || searchString.length <= 1)
      return 0;

    int k = 0; //zum finden des größten Substring
    int biggestK = 0; //speichert immer den größten Substring
    boolean stop; //falls false wurde der größte Substring schon gefunden

    while(k<searchString.length){
      stop = true;
      for(int i = 0; i < k; i++) {
        if(searchString[i] != searchString[searchString.length-k+i]) {
          stop = false;
          break;
        }
      }
      if(stop != false) {
        biggestK = k;
      }

      k++;

    }
    return biggestK;
  }

}
