package h03;

public class UnicodeNumberOfCharIndex implements FunctionToInt<Character>{


  /**
   * Returns the size of the Alphabet
   *
   * @return the size of the Alphabet
   */
  @Override
  public int sizeOfAlphabet() {
    return Character.MAX_VALUE + 1;
  }


  /**
   * Returns the Unicode Number of cha
   *
   * @param cha the Character
   * @return teh Unicode number of cha
   * @throws IllegalArgumentException never
   */
  @Override
  public int apply(Character cha) throws IllegalArgumentException {
    return cha;
  }
}
