package h03;

import org.jetbrains.annotations.NotNull;

public class EnumIndex <T extends Enum<T>>  implements FunctionToInt<T> {

  T[] enumConstants;


  /**
   * @param enumClass an enum Class (especially not null)
   */
  public EnumIndex(Class<T> enumClass){
      enumConstants = enumClass.getEnumConstants();
  }

  /**
   * Returns the size of the Alphabet
   *
   * @return the size of the Alphabet
   */
  @Override
  public int sizeOfAlphabet() {
    return enumConstants.length;
  }

  /**
   * Returns the Index of t in the Enumeration
   *
   * @param t the given enum
   * @return the Index of t in the Enumeration
   * @throws IllegalArgumentException never
   */
  @Override
  public int apply(T t) throws IllegalArgumentException {
    for (int i=0;i< enumConstants.length;i++){
      if (t.equals(enumConstants[i]))
        return i;
    }
    return -1; //Fall tritt nicht ein, nur da um Compiler zu befriedigen
  }

}

