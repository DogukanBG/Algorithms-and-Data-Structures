package h03;

public class testFunction implements FunctionToInt<Character>{

  @Override
  public int sizeOfAlphabet() {
    return 3;
  }

  @Override
  public int apply(Character t) throws IllegalArgumentException {
    if(t == 'a')
      return 0;
    if(t == 'b')
      return 1;
    else
      return 2;
  }

}
