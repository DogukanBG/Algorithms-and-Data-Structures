package h03;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ExampleJUnitTest {

  @Test
  public void testAddition() {
    assertEquals(2, 1 + 1);
  }
}
