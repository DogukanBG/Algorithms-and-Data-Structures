package h03;

import java.util.Iterator;
import java.util.List;

public class AutomatonTest {
  public static void main(String[] args){
    testFunction function = new testFunction();
    Character[] searchString = {'a', 'b', 'a', 'b', 'a', 'c', 'a'};
    PartialMatchLengthUpdateValuesAsAutomaton<Character> test = new PartialMatchLengthUpdateValuesAsAutomaton<Character>(function, searchString);
    List<Transition<Character>>[] automaton = test.getTheStates();
    Object[] alphabet = test.getRealAlp();
    for(Object c : alphabet)
      System.out.println(c);

    for(int i = 0; i < automaton.length; i++) {
      System.out.println("State: " + i + "--------------------");
      if(automaton[i] != null) {
        Iterator<Transition<Character>> iterator = automaton[i].iterator();
        while(iterator.hasNext()) {
          Transition<Character> transition = iterator.next();
          Iterator<Character> it = transition.listOfT.iterator();
          while(it.hasNext()) {
            System.out.println(transition.j + ": " + it.next());
          }
        }
      }
    }
    System.out.println(test.getPartialMatchLengthUpdate(2, 'd'));
  }
}
