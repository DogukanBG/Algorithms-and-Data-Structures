package h03;

import java.util.LinkedList;
import java.util.List;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class StringMatcherTestHans {

  enum TestEnum {
    ONE,
    TWO,
    THREE
  }

  @Test
  public void testFindAllMatches( ) {
    List<Character> testAlphabet1 = new LinkedList<Character>();
    testAlphabet1.add('a');
    testAlphabet1.add('b');
    testAlphabet1.add('c');

    FunctionToInt<Character> testFct10 = new SelectionOfCharsIndex(testAlphabet1);
    PartialMatchLengthUpdateValues<Character> testSearch10 = new PartialMatchLengthUpdateValuesAsAutomaton<>(testFct10, new Character[]{});
    StringMatcher<Character> testMatcher10 = new StringMatcher<Character>(testSearch10);

    List<Integer> resultList10 = testMatcher10.findAllMatches(new Character[]{'a', 'b', 'a', 'a', 'a', 'a', 'a', 'b', 'a', 'a', 'a', 'a'});
    List<Integer> expectedList10 = new LinkedList<Integer>();

    for (int i = 0; i < resultList10.size() || i < expectedList10.size(); i++) {
      assertEquals(resultList10.get(i), expectedList10.get(i));
    }
    assertThrows(IllegalArgumentException.class, () -> testMatcher10.findAllMatches(new Character[]{'z'}));
  }
}
