package h02.list_of_arrays;

import java.util.Iterator;
import java.util.function.Consumer;


public class ListOfArraysIterator<T> implements Iterator<T> {

  //Laufpointer
  private ListOfArraysItem<T> p;
  //Laufindex
  private int i = 0;

  public ListOfArraysIterator(ListOfArraysItem<T> head){ p = head; }

  @Override
  public boolean hasNext() {
    return p!=null && i<p.numberOfListElemsInArray;
  }

  @Override
  public T next() {
    T[] tmp = p.arrayOfElems;
    T key = tmp[i];
    if (i == p.numberOfListElemsInArray){
      i = 0;
      p = p.next;
    }
    else{
      i++;
    }
    return key;
  }


  //****************************** - Unsupported Operations - ******************************//

  @Override
  public void forEachRemaining(Consumer<? super T> action) { throw new UnsupportedOperationException();}

  @Override
  public void remove() {
    throw new UnsupportedOperationException();
  }
}
