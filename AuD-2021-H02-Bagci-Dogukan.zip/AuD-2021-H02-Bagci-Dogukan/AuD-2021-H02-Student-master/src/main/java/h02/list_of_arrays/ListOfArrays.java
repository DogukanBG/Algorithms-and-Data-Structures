package h02.list_of_arrays;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ListOfArrays <T> implements List<T> {

  private int LENGTH_OF_ALL_ARRAYS;
  private static int DEFAULT_LENGTH_OF_ALL_ARRAYS = 256;

  private ListOfArraysItem<T> head, tail;

  public ListOfArrays() {
    head = tail = null;
    LENGTH_OF_ALL_ARRAYS = DEFAULT_LENGTH_OF_ALL_ARRAYS;
  }

  public void readArrayLength(String path) throws IOException, NegativeArraySizeException {
    try(BufferedReader reader = new BufferedReader(new FileReader(path))){
       double arrayLength = Double.valueOf(reader.readLine());
       if (arrayLength != (int) arrayLength)
         throw new IOException();
       if (arrayLength < 0)
         throw new NegativeArraySizeException();
       LENGTH_OF_ALL_ARRAYS = (int) arrayLength;
    }catch(NumberFormatException exc){throw new IOException();}
  }

  @Override
  public boolean contains(Object o) {
    ListOfArraysItem<T> p = head;
    while(p!=null){
      T [] arr = p.arrayOfElems;
      for (int i = 0; i<p.numberOfListElemsInArray;i++){
       if (arr[i]==o)
         return true;
      }
      p = p.next;
    }
    return false;
  }

  @Override
  public boolean add(T t) {

    if (head == null){
      T[] arr =(T[]) new Object[LENGTH_OF_ALL_ARRAYS];
      arr[0] = t;
      ListOfArraysItem<T> tmp = new ListOfArraysItem<>();
      tmp.arrayOfElems = arr;
      tmp.numberOfListElemsInArray = 1;
      head = tail = tmp;
    }else{
      if (tail.numberOfListElemsInArray == tail.arrayOfElems.length){

        T[] arr =(T[]) new Object[LENGTH_OF_ALL_ARRAYS];
        ListOfArraysItem<T> tmp = new ListOfArraysItem<>();
        tmp.arrayOfElems = arr;
        tmp.previous = tail;
        tail.next = tmp;

        int m = tail.numberOfListElemsInArray/2;
        for (int i=0;i<m;i++){
            tail.next.arrayOfElems[i] = tail.arrayOfElems[i+m];
            tail.arrayOfElems[i+m] = null;
        }
        //für ungerade Arrays
        if (tail.numberOfListElemsInArray%2==1){
          tail.next.arrayOfElems[m] = tail.arrayOfElems[tail.numberOfListElemsInArray-1];
          tail.numberOfListElemsInArray = m;
          tail.next.numberOfListElemsInArray = m+1;
        }
        //für gerade Arrays
        else {
          tail.numberOfListElemsInArray = tail.numberOfListElemsInArray - m;
          tail.next.numberOfListElemsInArray = m;
        }
        tail = tail.next;
        tail.arrayOfElems[tail.numberOfListElemsInArray] = t;
        tail.numberOfListElemsInArray++;

      }else{
        tail.arrayOfElems[tail.numberOfListElemsInArray] = t;
        tail.numberOfListElemsInArray++;
      }
    }


    return true;
  }

  @Override
  public boolean addAll(Collection<? extends T> c) {
    if (c == null)
      throw new NullPointerException();
    Iterator<? extends T> it = c.iterator();
    while(it.hasNext()) {
      T t = it.next();
      if (head==null){
        T[] arr = (T[]) new Object[LENGTH_OF_ALL_ARRAYS];
        arr[0] = t;
        ListOfArraysItem<T> tmp = new ListOfArraysItem<>();
        tmp.numberOfListElemsInArray = 1;
        tmp.arrayOfElems = arr;
        head = tail = tmp;
        continue;
      }
      if (tail.arrayOfElems.length == tail.numberOfListElemsInArray) {
        T[] arr = (T[]) new Object[LENGTH_OF_ALL_ARRAYS];
        arr[0] = t;
        ListOfArraysItem<T> tmp = new ListOfArraysItem<>();
        tmp.numberOfListElemsInArray = 1;
        tmp.arrayOfElems = arr;
        tmp.previous = tail;
        tail.next = tmp;
        tail = tail.next;
      }
      else {
        tail.arrayOfElems[tail.numberOfListElemsInArray] = t;
        tail.numberOfListElemsInArray++;
      }
    }
    return true;
  }

  @Override
  public T get(int index) {
    if(index < 0 || index >= LENGTH_OF_ALL_ARRAYS) throw new IndexOutOfBoundsException();

    ListOfArraysItem<T> p = head;
    while(p!=null){
      T [] arr = p.arrayOfElems;
      for (int i = 0;i<arr.length;i++){
        if (index==0)
          return arr[i];
        index--;
      }

      p = p.next;
    }
    return null;
  }

  @Override
  public ListOfArraysIterator<T> iterator() { return new ListOfArraysIterator<>(head); }

  //****************************** - Unsupported Operations - ******************************//

  @Override
  public int size() { throw new UnsupportedOperationException(); }

  @Override
  public boolean isEmpty() { throw new UnsupportedOperationException(); }

  @Override
  public Object[] toArray() { throw new UnsupportedOperationException(); }

  @Override
  public <T1> T1[] toArray(T1[] a) { throw new UnsupportedOperationException(); }

  @Override
  public boolean remove(Object o) { throw new UnsupportedOperationException(); }

  @Override
  public boolean containsAll(Collection<?> c) { throw new UnsupportedOperationException(); }

  @Override
  public boolean addAll(int index, Collection<? extends T> c) { throw new UnsupportedOperationException(); }

  @Override
  public boolean removeAll(Collection<?> c) { throw new UnsupportedOperationException(); }

  @Override
  public boolean retainAll(Collection<?> c){ throw new UnsupportedOperationException(); }

  @Override
  public void clear() { throw new UnsupportedOperationException(); }

  @Override
  public T set(int index, T element) { throw new UnsupportedOperationException(); }

  @Override
  public void add(int index, T element){ throw new UnsupportedOperationException(); }

  @Override
  public T remove(int index){ throw new UnsupportedOperationException(); }

  @Override
  public int indexOf(Object o) { throw new UnsupportedOperationException(); }

  @Override
  public int lastIndexOf(Object o) { throw new UnsupportedOperationException(); }

  @Override
  public ListIterator<T> listIterator() { throw new UnsupportedOperationException(); }

  @Override
  public ListIterator<T> listIterator(int index) { throw new UnsupportedOperationException(); }

  @Override
  public List<T> subList(int fromIndex, int toIndex) { throw new UnsupportedOperationException(); }

  //****************************** - Methods only for testing - ******************************//

  //public ListOfArrays(ListOfArraysItem<T> head,ListOfArraysItem<T> tail) {
    //this.head = head;
    //this.tail = tail;
    //LENGTH_OF_ALL_ARRAYS = DEFAULT_LENGTH_OF_ALL_ARRAYS;
  //}

  //public int getLENGTH_OF_ALL_ARRAYS(){ return LENGTH_OF_ALL_ARRAYS; }

  //public ListOfArraysItem<T> getTail(){ return tail; }


}
