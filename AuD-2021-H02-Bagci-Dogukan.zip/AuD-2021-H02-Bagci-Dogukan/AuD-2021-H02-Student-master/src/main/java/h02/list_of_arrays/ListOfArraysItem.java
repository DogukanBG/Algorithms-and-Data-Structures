package h02.list_of_arrays;

class ListOfArraysItem <T> {

  public int numberOfListElemsInArray;
  public T[] arrayOfElems;
  public ListOfArraysItem <T> next,  previous;


  public ListOfArraysItem(){
      next = previous = null;
      arrayOfElems = null;
      numberOfListElemsInArray = 0;
  }

}
