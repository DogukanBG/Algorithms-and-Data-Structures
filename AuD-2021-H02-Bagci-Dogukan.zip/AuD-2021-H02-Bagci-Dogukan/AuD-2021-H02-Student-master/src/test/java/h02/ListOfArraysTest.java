package h02;

/*import h02.list_of_arrays.ListOfArrays;
import h02.list_of_arrays.ListOfArraysItem;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.*;*/

/**
 * TODO Instructions before starting a Test
 * 1. Make ListOfArrayItem public
 * 2. Uncomment all Methods and Constructors in the 'Methods only for testing' - Section in class ListOfArrays
 * 3. Create File 'H02Valid.txt' with Valid content and a File 'H02Invalid' with invalid
 * 4. Comment in all imports and all Methods in the Test Class
 * 5. Let's go
 */
/*
public class ListOfArraysTest {

  @Test
  public void testReadArrayLengthValid(){
    String fileName = "H02Valid.txt";
    ListOfArrays<Integer> listOfArrays = new ListOfArrays<>();

    try {
      listOfArrays.readArrayLength(fileName);
      assertEquals(10,listOfArrays.getLENGTH_OF_ALL_ARRAYS());
    } catch (IOException | NegativeArraySizeException exc) {
      exc.printStackTrace();
    }
  }

  @Test
  public void testReadArrayLengthInValidNegative(){
    String fileName = "H02Invalid.txt";
    ListOfArrays<Integer> listOfArrays = new ListOfArrays<>();
    assertThrows(NegativeArraySizeException.class,()->listOfArrays.readArrayLength(fileName));
  }

  @Test
  public void testReadArrayLengthInValidFileNotFound(){
    String fileName = "does not exist";
    ListOfArrays<Integer> listOfArrays = new ListOfArrays<>();
    assertThrows(IOException.class,()->listOfArrays.readArrayLength(fileName));
  }

  @Test
  public void testContainsTrue(){

    Integer[] ints = {0,1,2,3,4,null,null,null};
    Integer[] ints2 = {5,6,7,8,null,null,null,null};
    Integer[] ints3 = {null,10,11,12,null,null,null,null};
    Integer[] ints4 = {13,null,15,null,16,null,null,null};
    Integer[] ints5 = {17,18,19,20,21,22,23,24};

    ListOfArraysItem<Integer> head = new ListOfArraysItem<>();
    head.arrayOfElems = ints;
    head.numberOfListElemsInArray = 5;

    ListOfArraysItem<Integer> item1 = new ListOfArraysItem<>();
    item1.arrayOfElems = ints2;
    item1.numberOfListElemsInArray = 4;

    ListOfArraysItem<Integer> item2 = new ListOfArraysItem<>();
    item2.arrayOfElems = ints3;
    item2.numberOfListElemsInArray = 4;

    ListOfArraysItem<Integer> item3 = new ListOfArraysItem<>();
    item3.arrayOfElems = ints4;
    item3.numberOfListElemsInArray = 5;

    ListOfArraysItem<Integer> item4 = new ListOfArraysItem<>();
    item4.arrayOfElems = ints5;
    item4.numberOfListElemsInArray = 8;

    head.next = item1;
    item1.previous = head;

    item1.next = item2;
    item2.previous = item1;

    item2.next = item3;
    item3.previous = item2;

    item3.next = item4;
    item4.previous = item3;

    item4.next = null;

    ListOfArrays<Integer> listOfArrays = new ListOfArrays<>(head,item4);

    assertTrue(listOfArrays.contains(15));
  }

  @Test
  public void testContainsFalse(){

    Integer[] ints = {0,1,2,3,4,null,null,null};
    Integer[] ints2 = {5,6,7,8,null,null,null,null};
    Integer[] ints3 = {null,10,11,12,null,null,null,null};
    Integer[] ints4 = {13,null,15,null,16,null,null,null};
    Integer[] ints5 = {17,18,19,20,21,22,23,24};

    ListOfArraysItem<Integer> head = new ListOfArraysItem<>();
    head.arrayOfElems = ints;
    head.numberOfListElemsInArray = 5;

    ListOfArraysItem<Integer> item1 = new ListOfArraysItem<>();
    item1.arrayOfElems = ints2;
    item1.numberOfListElemsInArray = 4;

    ListOfArraysItem<Integer> item2 = new ListOfArraysItem<>();
    item2.arrayOfElems = ints3;
    item2.numberOfListElemsInArray = 4;

    ListOfArraysItem<Integer> item3 = new ListOfArraysItem<>();
    item3.arrayOfElems = ints4;
    item3.numberOfListElemsInArray = 5;

    ListOfArraysItem<Integer> item4 = new ListOfArraysItem<>();
    item4.arrayOfElems = ints5;
    item4.numberOfListElemsInArray = 8;

    head.next = item1;
    item1.previous = head;

    item1.next = item2;
    item2.previous = item1;

    item2.next = item3;
    item3.previous = item2;

    item3.next = item4;
    item4.previous = item3;

    item4.next = null;

    ListOfArrays<Integer> listOfArrays = new ListOfArrays<>(head,item4);

    assertTrue(!listOfArrays.contains(14));
  }

  @Test
  public void testAdd25(){
    Integer[] ints = {0,1,2,3,4,null,null,null};
    Integer[] ints2 = {5,6,7,8,null,null,null,null};
    Integer[] ints3 = {null,10,11,12,null,null,null,null};
    Integer[] ints4 = {13,null,15,null,16,null,null,null};
    Integer[] ints5 = {17,18,19,20,21,22,23,24};

    ListOfArraysItem<Integer> head = new ListOfArraysItem<>();
    head.arrayOfElems = ints;
    head.numberOfListElemsInArray = 5;

    ListOfArraysItem<Integer> item1 = new ListOfArraysItem<>();
    item1.arrayOfElems = ints2;
    item1.numberOfListElemsInArray = 4;

    ListOfArraysItem<Integer> item2 = new ListOfArraysItem<>();
    item2.arrayOfElems = ints3;
    item2.numberOfListElemsInArray = 4;

    ListOfArraysItem<Integer> item3 = new ListOfArraysItem<>();
    item3.arrayOfElems = ints4;
    item3.numberOfListElemsInArray = 5;

    ListOfArraysItem<Integer> item4 = new ListOfArraysItem<>();
    item4.arrayOfElems = ints5;
    item4.numberOfListElemsInArray = 8;

    head.next = item1;
    item1.previous = head;

    item1.next = item2;
    item2.previous = item1;

    item2.next = item3;
    item3.previous = item2;

    item3.next = item4;
    item4.previous = item3;

    item4.next = null;

    ListOfArrays<Integer> listOfArrays = new ListOfArrays<>(head,item4);

    assertTrue(listOfArrays.add(25));
    assertTrue(listOfArrays.getTail().numberOfListElemsInArray == 5);
    assertTrue(listOfArrays.contains(25));

    assertTrue(listOfArrays.add(26));
    assertTrue(listOfArrays.getTail().numberOfListElemsInArray == 6);
    assertTrue(listOfArrays.contains(26));

    assertTrue(listOfArrays.add(27));
    assertTrue(listOfArrays.getTail().numberOfListElemsInArray == 7);
    assertTrue(listOfArrays.contains(27));

    assertTrue(listOfArrays.add(28));
    assertTrue(listOfArrays.getTail().numberOfListElemsInArray == 8);
    assertTrue(listOfArrays.contains(28));

  }

  @Test
  public void testAddNull(){
    Integer[] ints = {0,1,2,3,4,null,null,null};
    Integer[] ints2 = {5,6,7,8,null,null,null,null};
    Integer[] ints3 = {null,10,11,12,null,null,null,null};
    Integer[] ints4 = {13,null,15,null,16,null,null,null};
    Integer[] ints5 = {17,18,19,20,21,22,23,24};

    ListOfArraysItem<Integer> head = new ListOfArraysItem<>();
    head.arrayOfElems = ints;
    head.numberOfListElemsInArray = 5;

    ListOfArraysItem<Integer> item1 = new ListOfArraysItem<>();
    item1.arrayOfElems = ints2;
    item1.numberOfListElemsInArray = 4;

    ListOfArraysItem<Integer> item2 = new ListOfArraysItem<>();
    item2.arrayOfElems = ints3;
    item2.numberOfListElemsInArray = 4;

    ListOfArraysItem<Integer> item3 = new ListOfArraysItem<>();
    item3.arrayOfElems = ints4;
    item3.numberOfListElemsInArray = 5;

    ListOfArraysItem<Integer> item4 = new ListOfArraysItem<>();
    item4.arrayOfElems = ints5;
    item4.numberOfListElemsInArray = 8;

    head.next = item1;
    item1.previous = head;

    item1.next = item2;
    item2.previous = item1;

    item2.next = item3;
    item3.previous = item2;

    item3.next = item4;
    item4.previous = item3;

    item4.next = null;

    ListOfArrays<Integer> listOfArrays = new ListOfArrays<>(head,item4);

    assertTrue(listOfArrays.add(null));
    assertTrue(listOfArrays.getTail().numberOfListElemsInArray == 5);
    assertTrue(listOfArrays.contains(null));

  }

  @Test
  public void testAddSame(){
    Integer[] ints = {0,1,2,3,4,null,null,null};
    Integer[] ints2 = {5,6,7,8,null,null,null,null};
    Integer[] ints3 = {null,10,11,12,null,null,null,null};
    Integer[] ints4 = {13,null,15,null,16,null,null,null};
    Integer[] ints5 = {17,18,19,20,21,22,23,24};

    ListOfArraysItem<Integer> head = new ListOfArraysItem<>();
    head.arrayOfElems = ints;
    head.numberOfListElemsInArray = 5;

    ListOfArraysItem<Integer> item1 = new ListOfArraysItem<>();
    item1.arrayOfElems = ints2;
    item1.numberOfListElemsInArray = 4;

    ListOfArraysItem<Integer> item2 = new ListOfArraysItem<>();
    item2.arrayOfElems = ints3;
    item2.numberOfListElemsInArray = 4;

    ListOfArraysItem<Integer> item3 = new ListOfArraysItem<>();
    item3.arrayOfElems = ints4;
    item3.numberOfListElemsInArray = 5;

    ListOfArraysItem<Integer> item4 = new ListOfArraysItem<>();
    item4.arrayOfElems = ints5;
    item4.numberOfListElemsInArray = 8;

    head.next = item1;
    item1.previous = head;

    item1.next = item2;
    item2.previous = item1;

    item2.next = item3;
    item3.previous = item2;

    item3.next = item4;
    item4.previous = item3;

    item4.next = null;

    ListOfArrays<Integer> listOfArrays = new ListOfArrays<>(head,item4);

    assertTrue(listOfArrays.add(25));
    assertTrue(listOfArrays.getTail().numberOfListElemsInArray == 5);
  }

  @Test  //also tests the iterator
  public void testAddAll(){
    Integer[] ints = {0,1,2,3,4,null,null,null};
    Integer[] ints2 = {5,6,7,8,null,null,null,null};
    Integer[] ints3 = {null,10,11,12,null,null,null,null};
    Integer[] ints4 = {13,null,15,null,17,null,null,null};
    Integer[] ints5 = {18,19,20,21,22,23,24,25};

    ListOfArraysItem<Integer> head = new ListOfArraysItem<>();
    head.arrayOfElems = ints;
    head.numberOfListElemsInArray = 5;

    ListOfArraysItem<Integer> item1 = new ListOfArraysItem<>();
    item1.arrayOfElems = ints2;
    item1.numberOfListElemsInArray = 4;

    ListOfArraysItem<Integer> item2 = new ListOfArraysItem<>();
    item2.arrayOfElems = ints3;
    item2.numberOfListElemsInArray = 4;

    ListOfArraysItem<Integer> item3 = new ListOfArraysItem<>();
    item3.arrayOfElems = ints4;
    item3.numberOfListElemsInArray = 5;

    ListOfArraysItem<Integer> item4 = new ListOfArraysItem<>();
    item4.arrayOfElems = ints5;
    item4.numberOfListElemsInArray = 8;

    head.next = item1;
    item1.previous = head;

    item1.next = item2;
    item2.previous = item1;

    item2.next = item3;
    item3.previous = item2;

    item3.next = item4;
    item4.previous = item3;

    item4.next = null;

    ListOfArrays<Integer> addThis = new ListOfArrays<>(head,item4);
    ListOfArrays<Integer> listOfArrays = new ListOfArrays<>();

    assertTrue(listOfArrays.addAll(addThis));
    Iterator<Integer> it = listOfArrays.iterator();

    for (int i = 0; it.hasNext(); i++) {
      Integer n = it.next();
      if (i == 9 || i == 14 || i == 16)
        assertTrue(n==null);
      else{
        assertTrue(n==i);
      }
    }
  }
}
*/
