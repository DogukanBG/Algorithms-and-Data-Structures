rootProject.name = "AuD-2021-H02-Student"
