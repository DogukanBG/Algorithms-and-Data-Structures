rootProject.name = "AuD-2021-H07-Student"
