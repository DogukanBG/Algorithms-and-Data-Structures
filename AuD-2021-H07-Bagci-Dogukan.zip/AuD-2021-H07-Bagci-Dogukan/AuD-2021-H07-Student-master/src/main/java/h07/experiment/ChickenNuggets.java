package h07.experiment;

import java.util.Comparator;
import java.util.Map;

import h07.algebra.IntegerAddition;
import h07.algebra.Monoid;
import h07.algorithm.Dijkstra;
import h07.graph.DirectedGraph;
import h07.graph.Path;

public class ChickenNuggets {

	public static int[] computePackageNumbers(int numberOfNuggets) {
		int destinationNode = Math.floorMod(numberOfNuggets, 6);
		Dijkstra<Integer, Integer> dijkstra = new Dijkstra<Integer, Integer>();
		ChickenNuggetGraphFactory factory = new ChickenNuggetGraphFactory();
		DirectedGraph<Integer, Integer> graph = factory.createDirectedGraph();
		
		Map<Integer, Path<Integer, Integer>> paths = dijkstra.shortestPaths(graph, 0,
				new IntegerAddition(),
	    		Comparator.naturalOrder());
		
		Path<Integer, Integer> path = paths.get(destinationNode);
		int[] nuggies = {0,0,0};
		Path.Traverser<Integer, Integer> trav =	path.traverser();
		while (trav.hasNextNode()) {
			Integer node = trav.getDistanceToNextNode();
			trav.walkToNextNode();
			if (node.equals(9)) {
				nuggies[1]++;
			}
			if (node.equals(20)) {
				nuggies[2]++;
			}
		}
		int rest = numberOfNuggets -  nuggies[1] * 9 - nuggies[2] * 20;
		nuggies[0] = rest/6;
		double check = ((double)rest)/((double)6);
		if (check != nuggies[0] || rest < 0) {
			return null;
		}
		return nuggies;	
	}
	
}
