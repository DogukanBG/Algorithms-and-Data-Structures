package h07.experiment;

import java.util.Comparator;

import h07.algebra.IntegerAddition;
import h07.algebra.Monoid;
import h07.algorithm.Dijkstra;
import h07.graph.AdjacencyMatrixFactory;
import h07.graph.DirectedGraph;

/*
import h07.algebra.IntegerAddition;
import h07.algorithm.Dijkstra;
import h07.graph.AdjacencyMatrixFactory;
*/

public class RoadTrip {
  public static void main(String[] args) {
    String[] nodes = {
      "München",
      "Augsburg",
      "Karlsruhe",
      "Erfurt",
      "Nürnberg",
      "Kassel",
      "Würzburg",
      "Stuttgart",
      "Mannheim",
      "Frankfurt"
    };
    
    String[] nodes2 = {	"0","1", "2", 
    					"3", "4", "5",
    					"30", "31", "32",
    					"10","11","12",
    					"13","14", "15",
    					"20", "21", "22",
    					"23", "24"};
    
    Integer[][] adjacencyMatrix2 = 
    {{null, 1, 10, 1, 10, 10, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
    {1, null, 10, 10, 1, 10, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
    {10, 10, null, 1, 10, 10, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
    {1, 10, 1, null, 1, 10, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
    {10, 1, 10, 1, null, 10, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
    {10, 10, 10, 10, 10, null, 1, null, 10, null, null, null, null, null, null, null, null, null, null, null},
    {null, null, null, null, null, 1, null, null, null, null, null, null, 10, null, null, null, null, null, null, null},
    {null, null, null, null, null, null, null, null, 1, null, null, null, null, 10, null, null, null, null, null, null},
    {null, null, null, null, null, 10, null, 1, null, null, null, null, null, null, null, null, null, null, null, null},
    {null, null, null, null, null, null, null, null, null, null, 10, 10, 1, 1, 10, null, null, null, null, null},
    {null, null, null, null, null, null, null, null, null, 10, null, 10, 10, 10, 10, 1, null, null, null, null},
    {null, null, null, null, null, null, null, null, null, 10, 10, null, 10, 10, 1, null, null, null, null, null},
    {null, null, null, null, null, null, null, null, null, 1, 10, 10, null, 10, 1, null, null, null, null, null},
    {null, null, null, null, null, null, 10, null, null, 1, 10, 10, 10, null, 1, null, null, null, null, null},
    {null, null, null, null, null, null, null, null, null, 10, 10, 1, 10, 1, null, null, null, null, null, null},
    {null, null, null, null, null, null, null, null, null, null, 1, null, null, null, null, null, 1, null, null},
    {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 1},
    {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 1, null, null, 10, null},
    {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 10, null, 1},
    {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 1, null, 1, null}
    };

    Integer[][] adjacencyMatrix = {
      {null, 84, null, null, 167, 502, null, null, null, null},
      {84, null, 250, null, null, null, null, null, null, null},
      {null, 250, null, null, null, null, null, null, 80, null},
      {null, null, null, null, null, null, 186, null, null, null},
      {167, null, null, null, null, null, 103, 183, null, null},
      {502, null, null, null, null, null, null, null, null, 173},
      {null, null, null, 186, 103, null, null, null, null, 217},
      {null, null, null, null, 183, null, null, null, null, null},
      {null, null, 80, null, null, null, null, null, null, 85},
      {null, null, null, null, null, 173, 217, null, 85, null}
    };
    
    AdjacencyMatrixFactory<String, Integer> factory = new AdjacencyMatrixFactory<>(nodes, adjacencyMatrix);
    DirectedGraph<String, Integer> graph = factory.createDirectedGraph();

    var dijkstra = new Dijkstra<String, Integer>();
 
    var paths = dijkstra.shortestPaths(
    		graph, "Frankfurt",
    		new IntegerAddition(),
    		Comparator.naturalOrder());
    
    AdjacencyMatrixFactory<String, Integer> factory2 = new AdjacencyMatrixFactory<>(nodes2, adjacencyMatrix2);
    DirectedGraph<String, Integer> graph2 = factory2.createDirectedGraph();
    
    var paths2 = dijkstra.shortestPaths(graph2, "20", new IntegerAddition(), Comparator.naturalOrder());
	
  

    // Sollte "Frankfurt -217-> Würzburg -103-> Nürnberg -167-> München"
    // ausgeben.
    System.out.println(paths.get("München"));
    System.out.println(paths2.get("3"));
    
  }
}
