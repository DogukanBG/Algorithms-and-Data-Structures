package h07.experiment;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Set;

import h07.graph.DirectedGraph;
import h07.graph.DirectedGraphFactory;


public class ChickenNuggetGraphFactory implements DirectedGraphFactory<Integer, Integer>{

	@Override
	public DirectedGraph<Integer, Integer> createDirectedGraph() {
		// TODO Auto-generated method stub
		ChickenNuggetGraph graph = new ChickenNuggetGraph();
		return graph;
	}
	
	private class ChickenNuggetGraph implements DirectedGraph<Integer, Integer>{
		
		private LinkedList<Node> allNodes = new LinkedList<>();
		
		public ChickenNuggetGraph() {
			Integer[] nodes = {0,1,2,3,4,5};
	
			Node node0 = new Node(nodes[0]);	
			Node node1 = new Node(nodes[1]);
			Node node2 = new Node(nodes[2]);
			Node node3 = new Node(nodes[3]);
			Node node4 = new Node(nodes[4]);
			Node node5 = new Node(nodes[5]);
			
			Arc arc02 = new Arc(node2, 20); Arc arc03 = new Arc(node3, 9);
			node0.arcs = new LinkedList<>();
			node0.arcs.add(arc02); node0.arcs.add(arc03); 
			
			Arc arc13 = new Arc(node3, 20);	Arc arc14 = new Arc(node4, 9);
			node1.arcs = new LinkedList<>();
			node1.arcs.add(arc13); node1.arcs.add(arc14);  
			
			Arc arc24 = new Arc(node4, 20); Arc arc25 = new Arc(node5, 9);
			node2.arcs = new LinkedList<>();
			node2.arcs.add(arc24); node2.arcs.add(arc25);  
			
			Arc arc35 = new Arc(node5, 20); Arc arc30 = new Arc(node0, 9);
			node3.arcs = new LinkedList<>();
			node3.arcs.add(arc35); node3.arcs.add(arc30);  
			
			Arc arc40 = new Arc(node0, 20); Arc arc41 = new Arc(node1, 9);
			node4.arcs = new LinkedList<>();
			node4.arcs.add(arc40); node4.arcs.add(arc41);  
			
			Arc arc51 = new Arc(node1, 20); Arc arc52 = new Arc(node2, 9);
			node5.arcs = new LinkedList<>();
			node5.arcs.add(arc51); node5.arcs.add(arc52); 
			
			allNodes.add(node0);
			allNodes.add(node1);
			allNodes.add(node2);
			allNodes.add(node3);
			allNodes.add(node4);
			allNodes.add(node5);
			
		}

		@Override
		public Collection<Integer> getAllNodes() {
			// TODO Auto-generated method stub
			Iterator<Node> it = allNodes.iterator();
			LinkedList<Integer> values = new LinkedList<>();
			while (it.hasNext()) {
				Node node = it.next();
				Integer v = node.value;
				values.add(v);
			}
			Set<Integer> setOfNodeValues = Set.copyOf(values);
			return setOfNodeValues;
		}

		@Override
		public Collection<Integer> getChildrenForNode(Integer node) {
			// TODO Auto-generated method stub
			if (node==null) {
				throw new NullPointerException("node is null");
			}
			Iterator<Node> it = allNodes.iterator();
			LinkedList<Integer> values = new LinkedList<>();
			while (it.hasNext()) {
				Node no = it.next();
				Integer v = no.value;
				if (v.equals(node)) {
					LinkedList<Arc> arcs = no.arcs;
					Iterator<Arc> it2 = arcs.iterator();
					while (it2.hasNext()) {
						Integer val = it2.next().endNode.value;
						values.add(val);
					}
					Set<Integer> setOfNodeValues = Set.copyOf(values);
					return setOfNodeValues;
				}
			}
			throw new NoSuchElementException("the graph does not contain the given node");
		}

		@Override
		public Integer getArcWeightBetween(Integer from, Integer to) {
			// TODO Auto-generated method stub
			if (from == null || to == null) {
				throw new NullPointerException("one of the given parameters was null");
			}
			Iterator<Node> it = allNodes.iterator();
			while (it.hasNext()) {
				Node node = it.next();
				Integer v = node.value;
				if (v.equals(from)) {
					LinkedList<Arc> arcs = node.arcs;
					Iterator<Arc> it2 = arcs.iterator();
					while (it2.hasNext()) {
						Arc arc = it2.next();
						Node no = arc.endNode;
						if (no.value.equals(to)) {
							return arc.arcWeight;
						}
					}
					throw new NoSuchElementException("the graph does not have a Arc from the start Node to the endNode");
				}
			}
			throw new NoSuchElementException("the graph does not contain the start Node");
		}

		@Override
		public void addNode(Integer node) {
			// TODO Auto-generated method stub
			throw new UnsupportedOperationException("Diese Methode wird in dieser Klasse nicht unterst�tzt");
		}

		@Override
		public void removeNode(Integer node) {
			// TODO Auto-generated method stub
			throw new UnsupportedOperationException("Diese Methode wird in dieser Klasse nicht unterst�tzt");
		}

		@Override
		public void connectNodes(Integer from, Integer weight, Integer to) {
			// TODO Auto-generated method stub
			throw new UnsupportedOperationException("Diese Methode wird in dieser Klasse nicht unterst�tzt");
		}

		@Override
		public void disconnectNodes(Integer from, Integer to) {
			// TODO Auto-generated method stub
			throw new UnsupportedOperationException("Diese Methode wird in dieser Klasse nicht unterst�tzt");
		}
		

		private class Node{
			
			private Integer value;
			private LinkedList<Arc> arcs = new LinkedList<>();
			
			private Node(Integer value) {
				this.value = value;
			}
			

		}
		
		private class Arc{
			
			Node endNode;
			Integer arcWeight;
			
			private Arc(Node endNode, Integer arcWeight) {
				this.endNode = endNode;
				this.arcWeight = arcWeight;
			}
			
		}
	}
	
	

}
