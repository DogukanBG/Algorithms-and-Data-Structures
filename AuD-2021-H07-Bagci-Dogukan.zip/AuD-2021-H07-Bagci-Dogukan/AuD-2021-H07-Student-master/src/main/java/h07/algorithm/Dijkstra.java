package h07.algorithm;


import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import h07.algebra.Monoid;
import h07.graph.DirectedGraph;
import h07.graph.Path;
import h07.graph.Path.Traverser;



public class Dijkstra<V, A> implements ShortestPathsAlgorithm<V, A> {

	@Override
	public Map<V, Path<V, A>> shortestPaths(DirectedGraph<V, A> graph, V startNode, Monoid<A> monoid,
			Comparator<? super A> comparator) {
		// TODO Auto-generated method stub
		Comparator<Triple> cmp = new Comparator<Triple>() {
			public int compare(Triple a1, Triple a2) {
				if (a1.totalWeight == null && a2.totalWeight == null) {
					return 0;
				}
				if (a2.totalWeight==null) {
					return -1;
				}
				if (a1.totalWeight==null) {
					return 1;
				}
				if (comparator.compare(a1.totalWeight, a2.totalWeight)<0) {
					return -1;
				}
				if (comparator.compare(a1.totalWeight, a2.totalWeight)>0) {
					return 1;
				}
				return 0;
			}
		};
		
		
		TreeSet<Triple> set = new TreeSet<>(cmp);
		Set<V> nodeSet = new TreeSet<>();
		HashMap<V, Path<V, A>> map = new HashMap<>();
		for (V node : graph.getAllNodes()) {
			if (startNode.equals(node)) {
				continue;
			}
			Triple triple = new Triple(node, null, monoid);
			set.add(triple);
			nodeSet.add(node);
			map.put(node, null);
		}
		Path<V, A> zeroPath = Path.of(startNode);
		map.put(startNode, zeroPath);
		Triple zeroTriple = new Triple(startNode, zeroPath, monoid);
		set.add(zeroTriple);
		nodeSet.add(startNode);
		
		while (set.size()!=0) {
			Triple triple = set.pollFirst();
			for (V node : graph.getChildrenForNode(triple.node)) {
				if (!nodeSet.contains(node)) {
					continue;
				}
				A arcWeight = graph.getArcWeightBetween(triple.node, node);
				Path<V,A> newPath = triple.path.concat(node, arcWeight);
				A newDistance = calculateWeight(monoid, newPath);
				A oldDistance = calculateWeight(monoid, map.get(node));
				if (oldDistance==null) {
					map.put(node, newPath);
					Triple newTriple = new Triple(node, newPath, monoid);
					set.add(newTriple);
					continue;
				}
				if (comparator.compare(newDistance,oldDistance)<0) {
					map.put(node, newPath);
					Triple newTriple = new Triple(node, newPath, monoid);
					set.add(newTriple);
				}
			}
			nodeSet.remove(triple.node);	
		}
		return map;
	}
	
	private class Triple{
		
		private V node;
		private Path<V, A> path;
		private A totalWeight;
		
		private Triple(V node, Path<V, A> path, Monoid<A> monoid) {
			this.node = node;
			this.path = path;
			
			if (path!=null) {
				Traverser<V, A> traverser = path.traverser();
				A a = monoid.zero();
				while (traverser.hasNextNode()) {
					A b = traverser.getDistanceToNextNode();
					if (b==null) {
						b = monoid.zero();
					}
					a = monoid.add(a, b);
					traverser.walkToNextNode();
				}
				totalWeight = a;	
			}
			else {
				totalWeight = null;
			}
			
			
		}
		
	}

	private A calculateWeight(Monoid<A> monoid, Path<V, A> path) {
		if (path==null) {
			return null;
		}
		Traverser<V, A> traverser = path.traverser();
		A a = monoid.zero();
		while (traverser.hasNextNode()) {
			A b = traverser.getDistanceToNextNode();
			if (b==null) {
				b = monoid.zero();
			}
			a = monoid.add(a, b);
			traverser.walkToNextNode();
		}
		return a;
	}

}
