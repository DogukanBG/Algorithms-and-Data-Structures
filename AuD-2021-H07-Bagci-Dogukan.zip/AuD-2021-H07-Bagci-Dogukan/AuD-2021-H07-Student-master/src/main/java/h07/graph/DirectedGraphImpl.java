package h07.graph;

import java.util.Collection;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Set;


class DirectedGraphImpl<V,A> implements DirectedGraph<V, A> {
	
	private LinkedList<Node> allNodes;
	
	DirectedGraphImpl() {
		// TODO Auto-generated constructor stub
		allNodes = new LinkedList<>();
	}
	
	

	 /**
	   * Liefert alle Knoten dieses Graphen als unveränderliche
	   * {@link java.util.Collection} von Knoten.
	   *
	   * @return eine unveränderliche {@link java.util.Collection} mit allen
	   * Knoten dieses Graphen als Elemente
	   */
	public Collection<V> getAllNodes() {
		// TODO Auto-generated method stub
		Iterator<Node> it = allNodes.iterator();
		LinkedList<V> values = new LinkedList<>();
		while (it.hasNext()) {
			Node node = it.next();
			V v = node.value;
			values.add(v);
		}
		Set<V> setOfNodeValues = Set.copyOf(values);
		return setOfNodeValues;
	}

	  /**
	   * Liefert die Kinder eines Knoten als unveränderliche
	   * {@link java.util.Collection} von Knoten.
	   *
	   * @param node der Knoten, dessen Kinder abgefragt werden sollen
	   * @return eine unveränderliche {@link java.util.Collection} mit den Kindern
	   * des übergebenen Knoten als Elemente
	   * @throws NullPointerException             falls der übergebene Knoten {@code null} ist
	   * @throws java.util.NoSuchElementException falls der übergebene Knoten
	   *                                          nicht in diesem Graphen existiert
	   */
	@Override
	public Collection<V> getChildrenForNode(V node) {
		// TODO Auto-generated method stub
		if (node==null) {
			throw new NullPointerException("node is null");
		}
		Iterator<Node> it = allNodes.iterator();
		LinkedList<V> values = new LinkedList<>();
		while (it.hasNext()) {
			Node no = it.next();
			V v = no.value;
			if (v.equals(node)) {
				LinkedList<Arc> arcs = no.arcs;
				Iterator<Arc> it2 = arcs.iterator();
				while (it2.hasNext()) {
					V val = it2.next().endNode.value;
					values.add(val);
				}
				Set<V> setOfNodeValues = Set.copyOf(values);
				return setOfNodeValues;
			}
		}
		throw new NoSuchElementException("the graph does not contain the given node");
	}

	
	  /**
	   * Liefert das Gewicht der Kante zwischen zwei Knoten.
	   *
	   * @param from der Knoten, von dem die Kante ausgeht
	   * @param to   der Knoten, auf den die Kante zeigt
	   * @return das Gewicht der Kante zwischen den beiden Knoten
	   * @throws NullPointerException             falls für einen der beiden Knoten
	   *                                          {@code null} als Parameter übergeben wird
	   * @throws java.util.NoSuchElementException falls einer der beiden Knoten
	   *                                          nicht in diesem Graphen existiert oder falls keine Kante vom
	   *                                          ersten zum zweiten Knoten existiert
	   */
	@Override
	public A getArcWeightBetween(V from, V to) {
		// TODO Auto-generated method stub
		if (from == null || to == null) {
			throw new NullPointerException("one of the given parameters was null");
		}
		Iterator<Node> it = allNodes.iterator();
		while (it.hasNext()) {
			Node node = it.next();
			V v = node.value;
			if (v.equals(from)) {
				LinkedList<Arc> arcs = node.arcs;
				Iterator<Arc> it2 = arcs.iterator();
				while (it2.hasNext()) {
					Arc arc = it2.next();
					Node no = arc.endNode;
					if (no.value.equals(to)) {
						return arc.arcWeight;
					}
				}
				throw new NoSuchElementException("the graph does not have a Arc from the start Node to the endNode");
			}
		}
		throw new NoSuchElementException("the graph does not contain the start Node");
	}

	  /**
	   * Fügt diesem Graphen einen Knoten hinzu, der bisher noch nicht im Graphen
	   * enthalten ist.
	   *
	   * @param node der Knoten, der hinzugefügt werden soll
	   * @throws NullPointerException          falls der hinzuzufügende Knoten {@code null}
	   *                                       ist
	   * @throws IllegalArgumentException      falls der übergebene Knoten bereits in
	   *                                       diesem Graphen enthalten ist
	   * @throws UnsupportedOperationException falls das Hinzufügen von Knoten von
	   *                                       diesem Graphen nicht unterstützt wird
	   */
	@Override
	public void addNode(V node) {
		// TODO Auto-generated method stub
		if (node==null) {
			throw new NullPointerException("the given node is null");
		}
		Iterator<Node> it = allNodes.iterator();
		while (it.hasNext()) {
			Node no = it.next();
			V v = no.value;
			if (v.equals(node)) {
				throw new IllegalArgumentException("the given node already exists in the graph");
			}
		}
		Node newNode = new Node(node);
		allNodes.add(newNode);
	}
	
	  /**
	   * Entfernt einen Knoten aus diesem Graphen.
	   * Gleichzeitig werden alle vom zu entfernenden Knoten ausgehenden Kanten
	   * aus diesem Graphen gelöscht.
	   *
	   * @param node der Knoten, der entfernt werden soll
	   * @throws NullPointerException             falls der zu entfernende Knoten {@code null}
	   *                                          ist
	   * @throws java.util.NoSuchElementException falls der übergebene Knoten
	   *                                          nicht in diesem Graphen enthalten ist
	   * @throws UnsupportedOperationException    falls das Entfernen von Knoten von
	   *                                          diesem Graphen nicht unterstützt wird
	   */
	@Override
	public void removeNode(V node) {
		// TODO Auto-generated method stub
		if (node==null) {
			throw new NullPointerException("the given node was null");
		}
		Iterator<Node> it = allNodes.iterator();
		boolean contains = false;
		while (it.hasNext()) {
			Node n = it.next();
			if (n.value.equals(node)) {
				n.arcs = null;
				it.remove();
				contains = true;
			}
			else {
				LinkedList<Arc> arcs = n.arcs;
				Iterator<Arc> it2 = arcs.iterator();
				while (it2.hasNext()) {
					Arc arc = it2.next();
					if (arc.endNode.value.equals(node)) {
						it2.remove();
					}
				}
			}
		}
		if (contains) {
			return;
		}
		throw new NoSuchElementException("the graph does not contain the given node");
	}
	
	
	  /**
	   * Verbindet zwei Knoten mit einer Kante.
	   *
	   * @param from   der Knoten von dem aus die neue Kante ausgehen soll
	   * @param weight das Gewicht der neuen Kante
	   * @param to     der Knoten, auf den die neue Kante zeigen soll
	   * @throws NullPointerException             falls für einen der Parameter {@code null}
	   *                                          übergeben wird
	   * @throws java.util.NoSuchElementException falls einer der beiden Knoten
	   *                                          nicht in diesem Graphen existiert
	   * @throws IllegalArgumentException         falls bereits eine Kante vom ersten zum
	   *                                          zweiten Knoten existiert
	   * @throws UnsupportedOperationException    falls das Hinzufügen von Kanten von
	   *                                          diesem Graphen nicht unterstützt wird
	   */
	@Override
	public void connectNodes(V from, A weight, V to) {
		// TODO Auto-generated method stub
		if (from == null || weight == null || to == null) {
			throw new NullPointerException("one of the given arguments is null");
		}
		Iterator<Node> it = allNodes.iterator();
		Node fromNode = null, toNode = null;
		while (it.hasNext()) {
			Node node = it.next();
			if (node.value.equals(from)) {
				fromNode = node;
			}
			if (node.value.equals(to)) {
				toNode = node;
			}
		}
		if (fromNode==null||toNode==null) {
			throw new NoSuchElementException("the graph does not contain one of the given nodes / both nodes");
		}
		else {
			Iterator<Arc> it2 = fromNode.arcs.iterator();
			while (it2.hasNext()) {
				Arc arc = it2.next();
				if (arc.endNode.value.equals(toNode.value)) {
					throw new IllegalArgumentException("there is already an Arc between the given nodes");
				}
			}
			Arc arc = new Arc(toNode, weight);
			fromNode.arcs.add(arc);
		}
	}

	
	  /**
	   * Entfernt die bestehende Kante zwischen zwei Knoten.
	   *
	   * @param from der Knoten, von dem die zu löschende Kante ausgeht
	   * @param to   der Knoten, auf den die zu löschende Kante zeigt
	   * @throws NullPointerException             falls für einen der beiden Knoten
	   *                                          {@code null} als Parameter übergeben wird
	   * @throws java.util.NoSuchElementException falls einer der beiden Knoten
	   *                                          nicht in diesem Graphen existiert oder falls keine Kante vom
	   *                                          ersten zum zweiten Knoten existiert
	   * @throws UnsupportedOperationException    falls das Entfernen von Kanten von
	   *                                          diesem Graphen nicht unterstützt wird
	   */
	@Override
	public void disconnectNodes(V from, V to) {
		// TODO Auto-generated method stub
		if (from == null || to == null) {
			throw new NullPointerException("one of the given arguments is null");
		}
		Iterator<Node> it = allNodes.iterator();
		while (it.hasNext()) {
			Node node = it.next();
			if (node.value.equals(from)) {
				Iterator<Arc> it2 = node.arcs.iterator();
				while (it2.hasNext()) {
					Arc arc = it2.next();
					if (arc.endNode.value.equals(to)) {
						it2.remove();
						return;
					}
					
				}
			}
		}
		throw new NoSuchElementException("the graph does not contain on of the given nodes / both nodes");
	}
	
	private class Node{
		
		private V value;
		private LinkedList<Arc> arcs = new LinkedList<DirectedGraphImpl<V,A>.Arc>();
		
		private Node(V value) {
			this.value = value;
		}
		

	}
	
	private class Arc{
		
		Node endNode;
		A arcWeight;
		
		private Arc(Node endNode, A arcWeight) {
			this.endNode = endNode;
			this.arcWeight = arcWeight;
		}
		
	}

}
