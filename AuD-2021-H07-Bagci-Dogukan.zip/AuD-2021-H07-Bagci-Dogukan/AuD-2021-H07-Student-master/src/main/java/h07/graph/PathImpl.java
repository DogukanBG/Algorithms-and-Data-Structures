package h07.graph;


import java.util.Iterator;

import java.util.NoSuchElementException;

import h07.graph.Path.Traverser;


class PathImpl<V, A> extends AbstractPath<V, A> {
	
	private PathObj head, tail;

	private PathImpl() {}
	
	PathImpl(V node) {
		//TODO
		PathObj newHead = new PathObj(node);
		head = tail = newHead;
	}
	
	  /**
	   * Liefert einen {@link Traverser}, mit dem sich dieser Pfad traversieren
	   * lässt.
	   * Beim aktuell betrachteten Knoten des {@code Traverser}s handelt es sich
	   * zunächst um den ersten Knoten in diesem Pfad.
	   *
	   * @return ein {@code Traverser} für diesen Pfad
	   */
	@Override
	public Traverser<V, A> traverser() {
		// TODO Auto-generated method stub
		return new TraverserImpl(head);
	}
	
	 /**
	   * Erzeugt einen neuen Pfad aus den Knoten und Kanten dieses Pfades und
	   * einem weiteren Knoten.
	   * Dieser wird durch eine neue Kante an den letzten Knoten dieses Pfades
	   * angehängt.
	   * Dieser Pfad wird durch diese Methode jedoch nicht verändert.
	   *
	   * @param node     der Knoten, der im neuen Pfad an den letzten Knoten
	   *                 dieses Pfades angehängt werden soll
	   * @param distance das Gewicht der neuen Kante, mit der der neue Knoten mit
	   *                 dem letzten Knoten dieses Pfades verbunden werden soll
	   * @return eine Kopie dieses Pfades mit einem zusätzlichen Knoten
	   * @throws NullPointerException falls der neue Knoten oder das Gewicht der
	   *                              neuen Kante {@code null} ist
	   */
	@Override
	public Path<V, A> concat(V node, A distance) {
		// TODO Auto-generated method stub
		if (node==null) {
			throw new NullPointerException("the given node is null");
		}
		if (distance == null) {
			throw new NullPointerException("the given distance is null");
		}
		PathObj newObj = new PathObj(node);
		newObj.distance = null;
		
		PathImpl<V, A> newPath = new PathImpl<>();
		PathObj p = head;
		
		while (p!=null) {
			PathObj obj = new PathObj();
			obj.key = p.key;
			obj.distance = p.distance;
			
			if (newPath.head == null) {
				newPath.head = newPath.tail = obj;
			}
			else {
				newPath.tail.next = obj;
				newPath.tail = newPath.tail.next;
			}	
			p = p.next;
		}
		newPath.tail.distance = distance;
		newPath.tail.next = newObj;
		newPath.tail = newPath.tail.next;
		return newPath;
	}

	@Override
	public Iterator<V> iterator() {
		// TODO Auto-generated method stub
		return new PathIterator(head);
	}
		
	private class PathObj{

		
		private V key;
		private A distance;
		private PathObj next;
		
		private PathObj() {}
		
		private PathObj(V key) {
			this.key = key;
			distance = null; next = null;
		}
	}
	
	private class TraverserImpl implements Traverser<V, A>{
		
		private PathObj current;
		
		private TraverserImpl(PathObj head) {
			this.current = head;
		}

		
		 /**
	     * Liefert den von diesem {@code Traverser} aktuell betrachteten Knoten.
	     *
	     * @return der aktuell betrachtete Knoten
	     */
		@Override
		public V getCurrentNode() {
			// TODO Auto-generated method stub
			return current.key;
		}

		/**
		 * Liefert das Gewicht der Kante vom aktuell betrachteten Knoten zu
		 * seinem Nachfolgeknoten.
	     *
	     * @return die Distanz zum nächsten Knoten.
	     * @throws IllegalStateException falls es sich beim aktuell betrachteten
	     *                               Knoten um den letzten Knoten im Pfad dieses
	     *                               {@code Traverser}s handelt
	     */
		@Override
		public A getDistanceToNextNode() {
			// TODO Auto-generated method stub
			if (!hasNextNode()) {
				throw new IllegalStateException("this Traverser Object doesn't have any nodes left to traverse");
			}
			return current.distance;
		}

		 /**
	     * @throws java.util.NoSuchElementException falls es sich beim aktuell
	     *                                          betrachteten Knoten um den letzten Knoten im Pfad dieses
	     *                                          {@code Traverser}s handelt.
	     */
		@Override
		public void walkToNextNode() {
			// TODO Auto-generated method stub
			if (!hasNextNode()) {
				throw new NoSuchElementException("this Traverser Object doesn't have any nodes left to traverse");
			}
			current = current.next;	
		}

	    /**
	     * Zeigt an, ob der aktuell betrachtete Knoten einen Nachfolgeknoten
	     * besitzt.
	     *
	     * @return {@code true} genau dann, wenn es sich beim aktuell
	     * betrachteten Knoten nicht um den letzten Knoten im Pfad
	     * dieses {@code Traverser}s handelt
	     */
		@Override
		public boolean hasNextNode() {
			// TODO Auto-generated method stub
			if (current.next==null) {
				return false;
			}
			return true;
		}
		
	}

	private class PathIterator implements Iterator<V>{
		
		private PathObj p;
		
		private PathIterator(PathObj head) {
			this.p = head;
		}

		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			if (p.next==null) {
				return false;
			}
			return true;
		}

		@Override
		public V next() {
			// TODO Auto-generated method stub
			if (!hasNext()) {
				throw new NoSuchElementException("this Iterator doesn't have any Nodes left");
			}
			V tmp = p.key;
			p= p.next;
			return tmp;
		}

	}
}
