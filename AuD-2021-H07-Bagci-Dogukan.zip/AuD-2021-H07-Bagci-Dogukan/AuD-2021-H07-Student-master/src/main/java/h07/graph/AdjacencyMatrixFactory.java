package h07.graph;


public class AdjacencyMatrixFactory<V, A> implements DirectedGraphFactory<V, A> {

	private final A[][] adjacencyMatrix;
	private final V[] nodes;
	
	public AdjacencyMatrixFactory(V[] nodes, A[][] adjacencyMatrix) {
		if (adjacencyMatrix == null || nodes == null) {
			throw new NullPointerException("one of the given arguments is null");
		}
		for (int i = 0; i < nodes.length; i++) {
			if (nodes[i] == null) {
				throw new NullPointerException("the nodes object at index " + i + "is null");
			}
		}
		if (adjacencyMatrix.length != nodes.length || adjacencyMatrix[0].length != nodes.length) {
			throw new IllegalArgumentException("the adjacencyMatrix and the nodes-Array do not have the same length");
		}
		this.adjacencyMatrix = adjacencyMatrix;
		this.nodes = nodes;
	}
	
	
	
	/**
	  * Erzeugt einen {@link DirectedGraph}.
	  *
	  * @return der {@code DirectedGraph}, der von dieses Fabrik erzeugt wird.
	  */
	@Override
	public DirectedGraph<V, A> createDirectedGraph() {
		// TODO Auto-generated method stub
		DirectedGraphImpl<V, A> graph = new DirectedGraphImpl<>();
		for (int i = 0; i < nodes.length; i++) {
			V valueI = nodes[i];
			graph.addNode(valueI);
		}
		for (int i = 0; i < adjacencyMatrix.length; i++) {
			for (int j = 0; j < adjacencyMatrix[i].length; j++) {
				V from = nodes[i];
				V to = nodes[j];
				
				if (adjacencyMatrix[i][j]==null) {
					continue;
				}
				A weight = adjacencyMatrix[i][j];
				graph.connectNodes(from, weight, to);
			}
		}
		return graph;
	}

}
