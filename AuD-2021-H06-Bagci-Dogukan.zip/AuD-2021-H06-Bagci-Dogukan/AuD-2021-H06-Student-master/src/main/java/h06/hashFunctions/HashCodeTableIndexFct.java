package h06.hashFunctions;



public class HashCodeTableIndexFct<T> implements OtherToIntFunction<T> {
	
	private final int OFFSET;
	private int initialTableSize;
	
	
	public HashCodeTableIndexFct(int initalTableSize, int offset) {
		OFFSET = offset;
		this.initialTableSize = initalTableSize;
	}

	@Override
	public int apply(T t) {
		int dividend = t.hashCode() + OFFSET;
		int divisor = initialTableSize;
		int result = Math.floorMod(dividend, divisor);
		return result;
	}

	@Override
	public int getTableSize() {
		return initialTableSize;
	}

	@Override
	public void setTableSize(int tableSize) {
		initialTableSize = tableSize;
	}

}
