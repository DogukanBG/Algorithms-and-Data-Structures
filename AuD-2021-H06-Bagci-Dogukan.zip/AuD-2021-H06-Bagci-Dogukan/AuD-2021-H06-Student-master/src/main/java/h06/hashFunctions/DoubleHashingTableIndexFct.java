package h06.hashFunctions;

public class DoubleHashingTableIndexFct<T> implements OtherAndIntToIntFunction<T> {
	
	private final HashCodeTableIndexFct<T> fct1, fct2;
	
	public DoubleHashingTableIndexFct(HashCodeTableIndexFct<T> fct1, HashCodeTableIndexFct<T> fct2) {
		this.fct1 = fct1;
		this.fct2 = fct2;
	}
	

	@Override
	public int apply(T t, int n) {
		int a = fct1.apply(t), b = fct2.apply(t);
		int ze = Math.floorMod(n, getTableSize()) * Math.floorMod(b, getTableSize()); //i' =  i mod x & b' =  b mod x
		int i_b = Math.floorMod(ze, getTableSize());  //i' * b' 
		int a_new = Math.floorMod(a, getTableSize()); //a' = a mod x 
		int a_ib = a_new + i_b;
		int result = Math.floorMod(a_ib, getTableSize());
		return result;
	}

	@Override
	public int getTableSize() {
		return fct1.getTableSize();
	}

	@Override
	public void setTableSize(int tableSize) {
		fct1.setTableSize(tableSize);
		fct2.setTableSize(tableSize);
	}

}
