package h06.hashFunctions;

public class LinearProbingTableIndexFct<T> implements OtherAndIntToIntFunction<T> {
	
	private final OtherToIntFunction<T> fct;
	
	public LinearProbingTableIndexFct(OtherToIntFunction<T> fct) {
		this.fct = fct;
	}

	@Override
	public int apply(T t, int n) {
		// TODO Auto-generated method stub
		int a = fct.apply(t);
		int tableSize = getTableSize();
		int a_i = Math.floorMod(a, tableSize) + Math.floorMod(n, tableSize);
		int result = Math.floorMod(a_i, tableSize);
		return result;
	}

	@Override
	public int getTableSize() {
		// TODO Auto-generated method stub
		return fct.getTableSize();
	}

	@Override
	public void setTableSize(int tableSize) {
		// TODO Auto-generated method stub
		fct.setTableSize(tableSize);
	}

}
