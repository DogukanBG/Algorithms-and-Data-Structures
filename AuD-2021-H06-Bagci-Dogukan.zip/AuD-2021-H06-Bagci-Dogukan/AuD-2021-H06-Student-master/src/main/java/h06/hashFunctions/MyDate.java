package h06.hashFunctions;


import java.util.Calendar;

public class MyDate {

	private final int YEAR;
	private final int MONTH;
	private final int DAY;
	private final int HOUR;
	private final int MINUTE;
	
	private final boolean BOOL;
	
	private final long year;
	private final long month;
	private final long day;
	private final long hour;
	private final long minute;
	private final long sum;
	
	public MyDate(Calendar cal, boolean bool) {
		// TODO Auto-generated constructor stub
		YEAR = cal.get(Calendar.YEAR); MONTH = cal.get(Calendar.MONTH); DAY  = cal.get(Calendar.DAY_OF_MONTH);
		HOUR = cal.get(Calendar.HOUR_OF_DAY); MINUTE = cal.get(Calendar.MINUTE);
		
		BOOL = bool;
		
		minute = 99991l; hour = 1234l; day = 3l; 
		month = 83231l; sum = 98927l;
		year = 4563766470487200l; //TODO 
	}
	
	public int hashCode() {
		if (BOOL) {
			int biggest_int = 2147483647;
			long mul1 = Math.floorMod(YEAR * year,biggest_int);
			long mul2 = Math.floorMod(MONTH* month,biggest_int);		
			long mul4 = Math.floorMod(HOUR * hour, biggest_int);
			long mul5 = Math.floorMod(DAY * day, biggest_int);
			long mul6 = Math.floorMod(MINUTE * minute, biggest_int);
			long sum = mul1 + mul2 + mul4 + mul5 + mul6;
			int result = Math.floorMod(sum, biggest_int);
			return result;
		}
		else {
			long sum2 = YEAR + MONTH + DAY + HOUR + MINUTE;
			long mul = sum * sum2;
			int biggest_int = 2147483647;
			int result = Math.floorMod(mul, biggest_int);
			return result;
		}
		
	}

	public int getYear() {
		return YEAR;
	}

	public int getMonth() {
		return MONTH;
	}

	public int getDay() {
		return DAY;
	}

	public int getHour() {
		return HOUR;
	}

	public int getMinute() {
		return MINUTE;
	}
	
	
}
