package h06.hashTables;

import java.util.Iterator;
import java.util.LinkedList;

import h06.hashFunctions.OtherToIntFunction;

@SuppressWarnings("unchecked")
public class MyListsHashMap<K, V> implements MyMap<K, V> {
	
	
	private final LinkedList<KeyValuePair<K,V>>[] table;
	private final OtherToIntFunction<K> fct;
	
	
	public MyListsHashMap(OtherToIntFunction<K> fct) {
		// TODO Auto-generated constructor stub
		this.fct = fct;
		this.table =(LinkedList<KeyValuePair<K, V>>[]) new LinkedList[fct.getTableSize()];
		for (int i = 0; i < table.length; i++) {
			table[i] = new LinkedList<>();
		}
	}
	
	@Override
	public boolean containsKey(K key) {
		// TODO Auto-generated method stub
		int index = fct.apply(key);
		Iterator<KeyValuePair<K, V>> it = table[index].iterator();
		while (it.hasNext()) {
			KeyValuePair<K, V> kv = it.next();
			K k = kv.getKey();
			if (k.equals(key)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public V getValue(K key) {
		// TODO Auto-generated method stub
		int index = fct.apply(key);
		Iterator<KeyValuePair<K, V>> it = table[index].iterator();
		while (it.hasNext()) {
			KeyValuePair<K, V> kv = it.next();
			K k = kv.getKey();
			if (k.equals(key)) {
				V v = kv.getValue();
				return v;
			}
		}
		return null;
	}

	@Override
	public V put(K key, V value) {
		// TODO Auto-generated method stub
		KeyValuePair<K, V> pair = new KeyValuePair<K, V>(key, value);
		int index = fct.apply(key);
		if (containsKey(key)) {
			 V oldV = remove(key);
			 table[index].add(0, pair);
			 return oldV;
		}
		table[index].add(0, pair);
		return null;
	}

	@Override
	public V remove(K key) {
		// TODO Auto-generated method stub
		int index = fct.apply(key);
		Iterator<KeyValuePair<K, V>> it = table[index].iterator();
		while (it.hasNext()) {
			KeyValuePair<K, V> kv = it.next();
			K k = kv.getKey();
			if (k.equals(key)) {
				V v = kv.getValue();
				it.remove();
				return v;
			}
		}
		return null;
	}

}
