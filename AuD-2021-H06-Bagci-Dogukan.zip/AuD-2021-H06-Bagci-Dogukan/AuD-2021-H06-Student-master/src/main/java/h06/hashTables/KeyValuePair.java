package h06.hashTables;

public class KeyValuePair<K, V> {
	
	private final K key;
	private V value;
	
	public KeyValuePair(K key, V value) {
		// TODO Auto-generated constructor stub
		this.key = key;
		this.setValue(value);
	}

	public K getKey() {
		return key;
	}

	public V getValue() {
		return value;
	}

	public void setValue(V value) {
		this.value = value;
	}

}
