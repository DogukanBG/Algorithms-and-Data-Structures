package h06.hashTables;

public interface MyMap<K, V> {
	
	boolean containsKey(K key);
	
	V getValue(K key);
	
	V put(K key, V value);
	
	V remove(K key);

}
