package h06.hashTables;


import h06.hashFunctions.OtherAndIntToIntFunction;

@SuppressWarnings("unchecked")
public class MyIndexHoppingHashMap<K, V> implements MyMap<K, V> {
	
	private K[] theKeys;
	private V[] theValues;
	
	private boolean[] occupiedSinceLastRehash;
	private int amountOfTrue;
	
	private int LENGTH_OF_ARRAYS;
	private final double REHASH_MULT;
	private final double THRESHOLD;
	
	private OtherAndIntToIntFunction<K> fct;
	

	public MyIndexHoppingHashMap(int tableSize,double mult, double threshold, OtherAndIntToIntFunction<K> fct) {
		LENGTH_OF_ARRAYS = fct.getTableSize();
		
		theKeys = (K[]) new Object[LENGTH_OF_ARRAYS];
		theValues = (V[]) new Object[LENGTH_OF_ARRAYS];
		
		occupiedSinceLastRehash = new boolean[LENGTH_OF_ARRAYS];
		amountOfTrue = 0;
		
		REHASH_MULT =mult;
		THRESHOLD = threshold;
		
		this.fct = fct;
	}
	

	@Override
	public boolean containsKey(K key) {
		for(int i = 0; i<LENGTH_OF_ARRAYS; i++) {
			int index = fct.apply(key, i);
			if (key.equals(theKeys[index])) {
				return true;
			}
		}
		return false;
	}

	@Override
	public V getValue(K key) {
		// TODO Auto-generated method stub
		for(int i = 0; i<LENGTH_OF_ARRAYS; i++) {
			int index = fct.apply(key, i);
			if (theKeys[index].equals(key)) {
				V v = theValues[index];
				return v;
			}
		}
		return null;
	}

	@Override
	public V put(K key, V value) {
		double fillRate = ((double) amountOfTrue)/((double) LENGTH_OF_ARRAYS);
		boolean notFound = true;
		boolean firstNull = true;
		int first = 0;
		if (fillRate>THRESHOLD) {
			rehash();
		}
		for(int i = 0; i<LENGTH_OF_ARRAYS; i++) {
			int index = fct.apply(key, i);
			if (theKeys[index] == null && occupiedSinceLastRehash[index] == true)
				continue;
			if (theKeys[index] == null && occupiedSinceLastRehash[index] == false) {
				notFound = false;
				theKeys[index] = key;
				theValues[index] = value;
				return null;
			}
			if (theKeys[index] == null ) {
				if (firstNull) {
					first = index;
				}
			}
			if (theKeys[index].equals(key)) {
				notFound = false;
				V tmp = theValues[index];
				theValues[index] = value;
				return tmp;
			}
		}
		if (notFound) {
			theKeys[first] = key;
			theValues[first] = value;
		}
		
		return null;
	}

	@Override
	public V remove(K key) {
		for(int i = 0; i<LENGTH_OF_ARRAYS; i++) {
			int index = fct.apply(key, i);
			if (theKeys[index].equals(key)) {
				V v = theValues[index];
				theKeys[index] = null;
				theValues[index] = null;
				return v;
			}
		}
		return null;
	}
	
	private void rehash() {
		int oldSize = LENGTH_OF_ARRAYS;
		int mult = (int) REHASH_MULT;
		int newSize = mult*LENGTH_OF_ARRAYS;
		fct.setTableSize(newSize);
		LENGTH_OF_ARRAYS = fct.getTableSize();
		
		K[] oldKeys = theKeys;
		V[] oldValues = theValues;
		boolean[] oldBools = occupiedSinceLastRehash;
		
		theKeys = (K[]) new Object[LENGTH_OF_ARRAYS];
		theValues = (V[]) new Object[LENGTH_OF_ARRAYS];
		occupiedSinceLastRehash = new boolean[LENGTH_OF_ARRAYS];
		amountOfTrue = 0;
		
		for (int i=0;i<oldSize;i++) {
			K k = oldKeys[i];
			V v = oldValues[i];
			put(k, v);
		}
		for (int i = 0; i<LENGTH_OF_ARRAYS; i++) {
			if (theKeys[i]!=null) {
				occupiedSinceLastRehash[i] = true;
				amountOfTrue++;
			}
			else {
				occupiedSinceLastRehash[i] = false;
			}
		}		
	}

}
