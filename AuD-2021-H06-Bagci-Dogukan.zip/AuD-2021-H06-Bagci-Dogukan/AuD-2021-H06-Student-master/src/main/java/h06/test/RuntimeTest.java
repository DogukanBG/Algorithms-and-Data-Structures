package h06.test;


import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;
import java.util.stream.LongStream;

import h06.hashFunctions.DoubleHashingTableIndexFct;
import h06.hashFunctions.HashCodeTableIndexFct;
import h06.hashFunctions.LinearProbingTableIndexFct;
import h06.hashFunctions.MyDate;
import h06.hashFunctions.OtherAndIntToIntFunction;
import h06.hashTables.MyIndexHoppingHashMap;
import h06.hashTables.MyListsHashMap;
import h06.hashTables.MyMap;


public class RuntimeTest {
	
	private LinkedList<MyDate> trueDateList = new LinkedList<>();
	private LinkedList<MyDate> falseDateList = new LinkedList<>();

	private final long MILISECONDS_FROM_1970_TO_2022;
	private final int TESTSET_SIZE = 60000;

	public RuntimeTest() {
		// TODO Auto-generated constructor stub
		
		Calendar date_2022 = Calendar.getInstance();
		date_2022.set(Calendar.SECOND, 0);
		date_2022.set(Calendar.MINUTE, 0);
		date_2022.set(Calendar.HOUR, 0);
		date_2022.set(Calendar.MONTH, Calendar.JANUARY);
		date_2022.set(Calendar.DAY_OF_MONTH, 0);
		date_2022.set(Calendar.YEAR,2022);
		
		long milis = date_2022.getTimeInMillis();
		MILISECONDS_FROM_1970_TO_2022 = milis;
		
		Random random = new Random();
		LongStream stream = random.longs(0,MILISECONDS_FROM_1970_TO_2022);
		Iterator<Long> it = stream.iterator();
		
		int count = 0;
		
		while (count<TESTSET_SIZE) {
			long lo = it.next();
			if (lo>=MILISECONDS_FROM_1970_TO_2022) {
				continue;
			}
			
			Calendar cal = Calendar.getInstance();
			cal.setTimeInMillis(lo);
			
			MyDate trueDate = new MyDate(cal, true);
			MyDate falseDate = new MyDate(cal, false);
			
			trueDateList.add(trueDate);
			falseDateList.add(falseDate);
			
			count++;
		}
		
	}
	
	public void Test(int i, int j, int k, int l) {
		LinkedList<MyDate> testSet = null;
		if (i == 1) {
			testSet = trueDateList;
		}
		else {
			testSet = falseDateList;
		}
		MyMap<MyDate, MyDate> testTable = null;
		OtherAndIntToIntFunction<MyDate> testFct = null;
		HashCodeTableIndexFct<MyDate> testHash = null;
		if (j==1) {
			//MyIndexHoppingMap
			int resize = 2;
			double threshold = 0.75;
			if (k==1) {
				//Offset 0 & LinearProbing
				int offset = 0;
				if (l==1) {
					//Big TableSize
					int tableSize = TESTSET_SIZE*3;
					testHash = new HashCodeTableIndexFct<>(tableSize, offset);
				}
				else {
					//Small TableSize
					int tableSize = (int) (TESTSET_SIZE*0.1);
					testHash = new HashCodeTableIndexFct<>(tableSize, offset);
				}
				testFct = new LinearProbingTableIndexFct<>(testHash);
			}
			else {
				//Offset 1 % Offset 42 & DoubleHash
				HashCodeTableIndexFct<MyDate> secHash = null;
				int offset = 1;
				int secOffset = 42;
				if (l==1) {
					//Big TableSize
					int tableSize = TESTSET_SIZE*3;
					testHash = new HashCodeTableIndexFct<>(tableSize, offset);
					secHash = new HashCodeTableIndexFct<>(tableSize, secOffset);
				}
				else {
					//Small TableSize
					int tableSize = (int) (TESTSET_SIZE*0.1);
					testHash = new HashCodeTableIndexFct<>(tableSize, offset);
					secHash = new HashCodeTableIndexFct<>(tableSize, secOffset);
				}
				testFct = new DoubleHashingTableIndexFct<>(testHash,secHash);
			}
			testTable = new MyIndexHoppingHashMap<>(testFct.getTableSize(),resize, threshold, testFct);
		}
		
		
		else {
			//MyListHashMap & Offset 0
			int offset = 0;
			if (l==1) {
				//Big TableSize
				int tableSize = TESTSET_SIZE*3;
				testHash = new HashCodeTableIndexFct<>(tableSize, offset);
			}
			else {
				//Small TableSize
				int tableSize = (int) (TESTSET_SIZE*0.1);
				testHash = new HashCodeTableIndexFct<>(tableSize, offset);
			}
			testTable = new MyListsHashMap<>(testHash);
		}
		final int ADD_COUNT = 45000;
		int addedCount = 0;
		
		Iterator<MyDate> addIt = testSet.iterator();
		while (addedCount<ADD_COUNT) {
			MyDate date = addIt.next();
			testTable.put(date, date);
			boolean shouldBeIn = testTable.containsKey(date);
			//System.out.println("shouldBeIn: " + shouldBeIn);
			addedCount++;
		}
		while (addIt.hasNext()) {
			MyDate date = addIt.next();
			boolean shouldNotBeIn = !testTable.containsKey(date);
			//System.out.println("shouldNotBeIn: " + shouldNotBeIn);
		}
		
		
			
	}
	
}
